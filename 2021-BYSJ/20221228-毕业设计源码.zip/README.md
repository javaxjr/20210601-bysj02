# Ja202006151SSM
## 实训
Ja202006151SSM
## 小组或个人
Hello World-刘万超
## 项目简介
SSM
## 使用git工具步骤

1. clone项目到本地：git clone http://114.116.195.127/ICSS.hVv70CYP4T/8p1FVHIZbrk.git
2. 完成项目代码
3. 添加项目代码到Git管理：git add .
4. 提交代码到git仓库：git commit -m "你的提交信息"
5. 将代码push到远程仓库：git push 
* 注意   >以上方法针对的是有git命令行操作经验的用户