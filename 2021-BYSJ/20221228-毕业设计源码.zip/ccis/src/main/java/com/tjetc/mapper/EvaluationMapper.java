package com.tjetc.mapper;

import com.tjetc.domain.Evaluation;

import java.util.List;

public interface EvaluationMapper {
    int addEvaluation(Evaluation evaluation);

    List<Evaluation> selectByIdAndOrderDetail(Integer product_id);
}
