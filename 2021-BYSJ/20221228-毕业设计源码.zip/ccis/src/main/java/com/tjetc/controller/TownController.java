package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Town;
import com.tjetc.service.TownService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/town")
public class TownController {

    @Autowired
    private TownService townService;
    @RequestMapping("/add")
    @ResponseBody
    public boolean add(Town town){
        int i=townService.add(town);
        return i>0?true:false;
    }

    @RequestMapping("/selectByName")
    public String selectByName(@RequestParam(defaultValue = "") String provinces_cities,
                               @RequestParam(defaultValue = "")String city_county,
                               @RequestParam(defaultValue = "") String tTown,
                               @RequestParam(defaultValue = "1")Integer pageNum,
                               @RequestParam(defaultValue = "5")Integer pageSize, Model model){

        Map<String,Object> map=new HashMap<String, Object>();
        map.put("provinces_cities",provinces_cities);
        map.put("city_county",city_county);
        map.put("tTown",tTown);

        PageInfo<Town> pageInfo=townService.selectByName(map,pageNum,pageSize);
        model.addAttribute("page",pageInfo);
        return "/addressRegion/list_town";
    }

    @RequestMapping("/selectById")
    public String selectById(Integer id,Model model){
        Town town=townService.selectById(id);
        model.addAttribute("town",town);
        return "/addressRegion/update_town";
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(Town town){
        int i=townService.updateById(town);
        return i>0?true:false;
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean delById(Integer id){
        int i=townService.delById(id);
        return i>0?true:false;
    }

}
