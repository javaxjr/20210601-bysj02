package com.tjetc.domain;

import java.util.List;

/*
* 商品表
* */
public class Product {

    private Integer id;//编号
    private String name;//名称
    private Double price;//单价
    private Integer count;//库存量
    private String photopath;//商品图片
    private String briefly;//商品简介
    private String details;//商品详情
    private String type;//商品类型
    private String companies;//商品所属公司
    private String turnover;//成交量
    private Integer orderDetail_id;//商品详情id

    private OrderDetail orderDetail;
    private List<OrderDetail> list;
    public Product() {
    }

    public Product(Integer id, String name, Double price, Integer count, String photopath, String briefly, String details, String type, String companies, String turnover, Integer orderDetail_id, OrderDetail orderDetail, List<OrderDetail> list) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.count = count;
        this.photopath = photopath;
        this.briefly = briefly;
        this.details = details;
        this.type = type;
        this.companies = companies;
        this.turnover = turnover;
        this.orderDetail_id = orderDetail_id;
        this.orderDetail = orderDetail;
        this.list = list;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", count=" + count +
                ", photopath='" + photopath + '\'' +
                ", briefly='" + briefly + '\'' +
                ", details='" + details + '\'' +
                ", type='" + type + '\'' +
                ", companies='" + companies + '\'' +
                ", turnover='" + turnover + '\'' +
                ", orderDetail_id=" + orderDetail_id +
                ", orderDetail=" + orderDetail +
                ", list=" + list +
                '}';
    }

    public List<OrderDetail> getList() {
        return list;
    }

    public void setList(List<OrderDetail> list) {
        this.list = list;
    }

    public Integer getOrderDetail_id() {
        return orderDetail_id;
    }

    public void setOrderDetail_id(Integer orderDetail_id) {
        this.orderDetail_id = orderDetail_id;
    }

    public OrderDetail getOrderDetail() {
        return orderDetail;
    }

    public void setOrderDetail(OrderDetail orderDetail) {
        this.orderDetail = orderDetail;
    }

    public String getCompanies() {
        return companies;
    }

    public void setCompanies(String companies) {
        this.companies = companies;
    }

    public String getTurnover() {
        return turnover;
    }

    public void setTurnover(String turnover) {
        this.turnover = turnover;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getPhotopath() {
        return photopath;
    }

    public void setPhotopath(String photopath) {
        this.photopath = photopath;
    }

    public String getBriefly() {
        return briefly;
    }

    public void setBriefly(String briefly) {
        this.briefly = briefly;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
