package com.tjetc.mapper;

import com.tjetc.domain.Town;

import java.util.List;
import java.util.Map;

public interface TownMapper {
    int add(Town town);

    List<Town> selectByName(Map<String, Object> map);

    Town selectById(Integer id);

    int updateById(Town town);

    int delById(Integer id);

    List<Town> selectByTTownAndCityCounty(String city_county);
}
