package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Business;
import com.tjetc.service.BusinessService;
import com.tjetc.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/business")
public class BusinessController {

    @Autowired
    private BusinessService businessService;
    @Autowired
    private CommonService commonService;

    @RequestMapping("/add")
    @ResponseBody
    private boolean add(Business business, HttpServletRequest request) {
        business.setBalance(10000);
        int i = businessService.add(business);
        return i > 0 ? true : false;
    }

    @RequestMapping("/selectByBusinessName")
    public String selectByBusinessName(@RequestParam(defaultValue = "") String business_name,
                                       @RequestParam(defaultValue = "1") Integer pageNum,
                                       @RequestParam(defaultValue = "10") Integer pageSize, Model model) {

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("business_name", business_name);
        //PageInfo<Business> pageInfo = commonService.selectByName(map, pageNum, pageSize, new Business());
        PageInfo<Business> pageInfo = businessService.selectByBusinessName(business_name, pageNum, pageSize);
        model.addAttribute("page", pageInfo);
        model.addAttribute("business_name", business_name);


        return "/business/list_businss";

    }

    @RequestMapping("/findById")
    @ResponseBody
    public Business findById(Integer id) {
        return businessService.findById(id);
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(Business business) {

        int i = businessService.updateById(business);
        return i > 0 ? true : false;
    }

    @RequestMapping("/deleteById")
    @ResponseBody
    public boolean deleteById(Integer id) {
        return businessService.deleteById(id);
    }

}
