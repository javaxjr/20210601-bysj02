package com.tjetc.util.excel;

import com.tjetc.domain.Product;
import com.tjetc.util.ExcelUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/*
 * 实现数据信息进行批量上传
 * */

public class UploadExcelAndList {

    public static List addUploadExcel(MultipartFile excel) {

        if (excel==null){
            return null;
        }
        InputStream in = null;
        try {
            in = excel.getInputStream();
            //获取Excel对象
            Workbook workbook = null;
            //获得文件名
            String fileName = excel.getOriginalFilename();
            System.out.println("文件名称 = " + fileName);

            //根据后缀，得到不同的workbook子类，即HSSFWorkbook或XSSFWorkbook
            if (excel.getOriginalFilename().endsWith("xlsx")){
                workbook = new XSSFWorkbook(in);//给定输入流读取文件创建XLSX操作对象
            }else if (excel.getOriginalFilename().endsWith("xls")){
                workbook = new HSSFWorkbook(in);//给定输入流读取文件创建XLS操作对象
            }else {
                return null;
                //throw new  Exception("文件格式不正确，或者文件已损坏");
            }
            //获取sheet对应对象，获取第一页对象
            Sheet sheet = workbook.getSheetAt(0);
            //创建station对象容器
            Product product;
            //解析sheet，获取多行数据，并放入迭代器中
            Iterator<Row> ito = sheet.iterator();
            int count = 0;
            int sum = 0;
            Sheet sheet1 = null;
            Row row = null;
            //每次导入就把上次的删除
            //delInterfaceList();
            List<Product> productList=new ArrayList<Product>();

            int i = workbook.getNumberOfSheets();
            System.out.println("i = " + i);

            while (ito.hasNext()){
                row = ito.next();
                //由于第一行是标题行，因此单独处理
                if (count == 0){
                    ++count;
                    continue;
                }else {
                    if (row != null){
                        product = new Product();
                        String name = ExcelUtils.getCelValue(row.getCell(0));
                        if (name==null){
                            break;
                        }
                        Double price = Double.valueOf(ExcelUtils.getCelValue(row.getCell(1)));
                        Integer pcount = Integer.valueOf(ExcelUtils.getCelValue(row.getCell(2)));
                        String photopath = ExcelUtils.getCelValue(row.getCell(3));
                        String briefly = ExcelUtils.getCelValue(row.getCell(4));
                        String details = ExcelUtils.getCelValue(row.getCell(5));
                        String type = ExcelUtils.getCelValue(row.getCell(6));
                        String companies = ExcelUtils.getCelValue(row.getCell(7));
                        String turnover = ExcelUtils.getCelValue(row.getCell(8));
                        if (turnover==null || (turnover!=null && turnover.trim().length()==0)){
                            turnover="0";
                        }

                        //为对象赋值
                        product.setName(name);
                        product.setPrice(price);
                        product.setCount(pcount);
                        product.setPhotopath(photopath);
                        if (photopath==null || (photopath !=null && photopath.trim().length()==0)){
                            product.setPhotopath("upload/6fb0dfccyifu06.jpg");
                        }
                        product.setBriefly(briefly);
                        product.setDetails(details);
                        product.setType(type);
                        product.setCompanies(companies);
                        product.setTurnover(turnover);

                        //将商品对象放入到List集合中
                        productList.add(product);
                    }
                }
            }
            return productList;

        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}
