package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.CityCounty;

import java.util.List;
import java.util.Map;

public interface CityCountyService {
    boolean add(CityCounty cityCounty);

    PageInfo<CityCounty> selectByName(Map<String, Object> map, Integer pageNum, Integer pageSize);

    CityCounty selectById(Integer id);

    boolean updateById(CityCounty cityCounty);

    boolean delById(Integer id);

    List<CityCounty> selectByCtyCounty(String provinces_cities);
}
