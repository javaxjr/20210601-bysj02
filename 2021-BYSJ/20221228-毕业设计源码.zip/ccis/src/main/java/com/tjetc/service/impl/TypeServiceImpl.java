package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Product;
import com.tjetc.domain.Type;
import com.tjetc.mapper.TypeMapper;
import com.tjetc.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class TypeServiceImpl implements TypeService {
    @Autowired
    private TypeMapper typeMapper;
    public boolean add(Type type) {
        return (typeMapper.add(type))>0?true:false;
    }

    public PageInfo<Type> listByName(Map<String, Object> map, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<Type> list=typeMapper.listByName(map);
        PageInfo<Type> pageInfo = new PageInfo<Type>(list);

        return pageInfo;
    }

    public Type findById(Integer id) {
        return typeMapper.findById(id);
    }

    public boolean updateById(Type type) {
        return (typeMapper.updateById(type))>0?true:false;
    }

    public boolean delById(Integer id) {
        return (typeMapper.delById(id))>0?true:false;
    }

    public List<Type> selectByProductType() {
        return typeMapper.selectByProductType();
    }

    public List<Type> selectProductByType(String type) {
        return typeMapper.selectProductByType(type);
    }
}
