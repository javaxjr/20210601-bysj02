package com.tjetc.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.User;
import com.tjetc.domain.UserLoginAndTimeline;
import com.tjetc.service.UserLoginAndTimelineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/userLoginAndTimeline")
public class UserLoginAndTimelineController {

    @Autowired
    private UserLoginAndTimelineService userLoginAndTimelineService;

    @RequestMapping("/selectUserLoginAndTimelineByUid")
    @ResponseBody
    public PageInfo<UserLoginAndTimeline> selectUserLoginAndTimelineByUid(HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Integer userId = user.getId();
        PageInfo<UserLoginAndTimeline> pageInfo = userLoginAndTimelineService.selectUserLoginAndTimelineByUid(userId);
        return pageInfo;
    }

}
