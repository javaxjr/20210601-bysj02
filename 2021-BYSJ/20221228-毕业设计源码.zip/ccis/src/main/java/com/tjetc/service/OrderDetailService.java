package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.OrderDetail;

import java.util.List;
import java.util.Map;

public interface OrderDetailService {
    int add(OrderDetail orderDetail);

    PageInfo<OrderDetail> listByName(String name, Integer pageNum, Integer pageSize);

    OrderDetail findById(Integer id);

    int updateById(OrderDetail orderDetail);

    int deleById(Integer id);

    PageInfo<OrderDetail> listByNameS(Map<String, Object> map, Integer pageNum, Integer pageSize);

    List<OrderDetail> selectOrderDetail();

}
