package com.tjetc.controller;

import com.tjetc.domain.Provisional;
import com.tjetc.domain.User;
import com.tjetc.service.ProductService;
import com.tjetc.service.ProvisionalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@RestController
@RequestMapping("/provisional")
public class ProvisionalController {

    @Autowired
    private ProvisionalService provisionalService;
    //Integer user_id,Integer product_id,Integer count,boolean myCat_status

    @RequestMapping("/add")
    public boolean add(Provisional provisional){
        System.out.println("provisional = " + provisional);
        int i=provisionalService.add(provisional);
        return i>0?true:false;
    }

    @RequestMapping("/delByPIdAndUId")
    public boolean delByPIdAndUId(Integer user_id,Integer product_id){
        Provisional provisional = new Provisional();
        provisional.setUser_id(user_id);
        provisional.setProduct_id(product_id);
        int i=provisionalService.delByPIdAndUId(provisional);
        return i>0?true:false;
    }

    @RequestMapping("/selectByProvisional")
    public boolean selectByProvisional(HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        List<Provisional> list = provisionalService.selectByProvisional(user.getId());
        return list.size()>0?true:false;
    }

}
