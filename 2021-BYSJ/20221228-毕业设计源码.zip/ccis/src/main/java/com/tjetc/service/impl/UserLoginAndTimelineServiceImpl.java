package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.UserLoginAndTimeline;
import com.tjetc.mapper.UserLoginAndTimelineMapper;
import com.tjetc.service.UserLoginAndTimelineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserLoginAndTimelineServiceImpl implements UserLoginAndTimelineService {

    @Autowired
    private UserLoginAndTimelineMapper userLoginAndTimelineMapper;

    public void addUserTimeline(UserLoginAndTimeline usertimeline) {
        userLoginAndTimelineMapper.addUserTimeline(usertimeline);
    }

    public PageInfo<UserLoginAndTimeline> selectUserLoginAndTimelineByUid(Integer userId) {
        PageHelper.startPage(1,10);
        List<UserLoginAndTimeline> list = userLoginAndTimelineMapper.selectUserLoginAndTimelineByUid(userId);
        PageInfo<UserLoginAndTimeline> pageInfo = new PageInfo<UserLoginAndTimeline>(list);
        return pageInfo;
    }
}
