package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Order;

import java.util.List;
import java.util.Map;

public interface OrderService {
    int addSettleAccounts(Order order);

    int updateOrdersAddress(Order order);

    Order selectByMyCartId(Map<String,Object> map);

    List<Order> selectByUserId(Integer userId);

    int updateOrderByState(Order order);


    PageInfo<Order> selectUserOrders(Map map, Integer pageNum, Integer pageSize);

    List<Order> selectOrderStatus(Map<String,Object> map);

    List<Order> selectState(Map<String,Object> map);

    int deleteById(Integer order_id);

    Order selectByIdAndOrder(Integer id);

    int updateByIdOrderStatus(Order order);

    boolean deleteOrderById(Integer id);

    void updateOrderEvaluate(Order order);

    List<Order> selectByOrderEvaluate(Map<String,Object> map);

    Order selectOrderApplyForRefundById(Integer id);

    int updateOrderApplySubmit(Order order);

    List<Order> selectOrderByReasonsRefund();

    PageInfo<Order> listByNameAndOrdersReasonsRefund(Map<String, Object> map, Integer pageNum, Integer pageSize);

    Order findOrderById(Integer id);

    int updateByIdAndOrder(Order order);

    PageInfo<Order> selectOrderByNameLayui(Map<String, Object> map, int pageNum, int pageSize);

    PageInfo<Order> selectUserOrderByReason(Map<String, Object> map, int pageNum, int pageSize);

    List<Order> selectOrderByExpeditingDelivery();

    int updateOrderByIdAndStatedAndStatus(Order order);

    int updateOrdersExpeditingDelivery(Order order);

    int deleOrderByNoPayment(Map<String, Object> map);
}
