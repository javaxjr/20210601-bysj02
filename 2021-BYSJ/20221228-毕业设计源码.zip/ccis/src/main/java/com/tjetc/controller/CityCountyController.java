package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.AddressRegion;
import com.tjetc.domain.CityCounty;
import com.tjetc.domain.Town;
import com.tjetc.service.AddressRegionService;
import com.tjetc.service.CityCountyService;
import com.tjetc.service.TownService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
* 市县表控制层
* */
@Controller
@RequestMapping("/cityCounty")
public class CityCountyController {

    @Autowired
    private CityCountyService cityCountyService;

    @Autowired
    private AddressRegionService addressRegionService;

    @Autowired
    private TownService townService;

    @GetMapping("/add")
    public String add(){
        return "addressRegion/add_ctyCounty";
    }
    @PostMapping("/add")
    @ResponseBody
    public boolean add(CityCounty cityCounty){
        return  cityCountyService.add(cityCounty);
    }

    //查询省份
    @RequestMapping("/selectByAddressRegion")
    @ResponseBody
    public List<AddressRegion> selectByAddressRegion(){
        return addressRegionService.selectByAddressRegion();
    }

    //根据已选择的省份信息，进而查询与之相关的市县信息
    @RequestMapping("/selectByCtyCounty")
    @ResponseBody
    public List<CityCounty> selectByCtyCounty(@RequestParam(defaultValue = "") String provinces_cities){
        List<CityCounty> list=new ArrayList<CityCounty>();
        if (!"".equals(provinces_cities)){
            list=cityCountyService.selectByCtyCounty(provinces_cities);
        }

        //System.out.println("list = " + list);
        return list;
    }
    //根据已选择的省份信息，市县，进而查询与之相关的城镇信息
    @RequestMapping("/selectByTTownAndCityCounty")
    @ResponseBody
    public List<Town> selectByTTownAndCityCounty(String city_county){
        List<Town> list = townService.selectByTTownAndCityCounty(city_county);
        return list;
    }

    @RequestMapping("/selectByName")
    @ResponseBody
    public PageInfo<CityCounty> selectByName(@RequestParam(defaultValue = "") String provinces_cities,
                                @RequestParam(defaultValue = "")String city_county,
                                @RequestParam(defaultValue = "1")Integer pageNum,
                                @RequestParam(defaultValue = "5")Integer pageSize, Model model){

        Map<String,Object> map=new HashMap<String,Object>();
        map.put("provinces_cities",provinces_cities);
        if (city_county!=null && city_county.trim().length()>0){
            city_county=city_county.trim();
        }
        map.put("city_county",city_county);
        PageInfo<CityCounty> pageInfo=cityCountyService.selectByName(map,pageNum,pageSize);


        /*model.addAttribute("page",pageInfo);
        model.addAttribute("provinces_cities",provinces_cities);
        model.addAttribute("city_county",city_county);*/
        return pageInfo;
    }

    @RequestMapping("/selectById")
    @ResponseBody
    public Map<String,Object> selectById(Integer id){

        Map<String,Object> map=new HashMap<String, Object>();
        List<AddressRegion> list = addressRegionService.selectByAddressRegion();
        //System.out.println("list = " + list);
        CityCounty cityCounty = cityCountyService.selectById(id);

        map.put("list",list);
        map.put("cityCounty",cityCounty);

        return map;
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(CityCounty cityCounty){
        return cityCountyService.updateById(cityCounty);
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean delById(Integer id){
        return cityCountyService.delById(id);
    }




}
