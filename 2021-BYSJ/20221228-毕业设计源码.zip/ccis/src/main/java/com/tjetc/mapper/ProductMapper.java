package com.tjetc.mapper;

import com.alibaba.fastjson.JSONObject;
import com.tjetc.domain.Product;

import java.util.List;
import java.util.Map;

public interface ProductMapper {
    int add(Product product);

    List<Product> listByName(String brand);

    Product findById(Integer id);

    int updateById(Product product);

    int deleteById(Integer id);

    List<Product> selectProduct();

    Product selectByIdAndOrderDetail(Integer product_id);

    List<Product> selectSearchByType(String type);

    List<String> selectProvince();
}
