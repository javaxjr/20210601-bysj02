package com.tjetc.service.impl;

import com.tjetc.domain.CollectionNow;
import com.tjetc.mapper.CollectionNowMapper;
import com.tjetc.service.CollectionNowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CollectionNowServiceImpl implements CollectionNowService {

    @Autowired
    private CollectionNowMapper collectionNowMapper;

    public int addCollectionNow(CollectionNow collectionNow) {
        return collectionNowMapper.addCollectionNow(collectionNow);
    }

    public List<CollectionNow> selectByUserCollectionNow(Integer user_id) {
        return collectionNowMapper.selectByUserCollectionNow(user_id);
    }

    public CollectionNow selectByPidAndUid(CollectionNow collectionNow) {
        return collectionNowMapper.selectByPidAndUid(collectionNow);
    }

    public void deleteById(Integer id) {
        collectionNowMapper.deleteById(id);
    }
}
