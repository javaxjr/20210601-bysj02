package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.User;
import com.tjetc.service.ProvisionalService;
import com.tjetc.service.UserService;
import com.tjetc.util.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private ProvisionalService provisionalService;

    @RequestMapping("/selectByUserObject")
    @ResponseBody
    private boolean selectByUserName(@RequestParam(defaultValue = "") String username,
                                     @RequestParam(defaultValue = "") String phone,Model model){

        Map<String,Object> map = new HashMap<String, Object>();
        map.put("username",username);
        map.put("phone",phone);

        model.addAttribute("username",username);
        model.addAttribute("phone",phone);
        User user = userService.selectByUserObject(map);
        return user!=null?true:false;
    }


    @GetMapping("/add_user")
    public String addUser(){
        return "user/add_user";
    }

    @PostMapping("/add_user")
    @ResponseBody
    public boolean addUser(User user, MultipartFile photo, HttpServletRequest request, Model model){
        if (photo!=null && photo.getSize()>0){
            String realPath = request.getServletContext().getRealPath("/user_upload/");
            File file = new File(realPath);
            if (!file.exists()){
                file.mkdir();
            }
            String filename = photo.getOriginalFilename();
            //System.out.println("filename = " + filename);
            String filenameUUID = UUID.randomUUID().toString().replace("-","")+filename.substring(filename.lastIndexOf("."));
            //System.out.println("filenameUUID = " + filenameUUID);
            File file2 = new File(file, filenameUUID);
           /* String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filenameUUID;*/
            try {
                photo.transferTo(file2);
            } catch (IOException e) {
                e.printStackTrace();
            }
            user.setPhotopath("user_upload/"+filenameUUID);
        }else{
            user.setPhotopath("user_upload/599e55c4d4cd49f5879e69988533c98c.jpg");
        }
        //给登录密码进行加密
        String password = user.getPassword();
        String passwordMd5 = MD5Utils.stringToMD5(password);
        user.setPassword(passwordMd5);
        //给支付密码加密
        String payment = user.getPayment();
        if (payment!=null && payment.length()>0){
            String paymentMd5 = MD5Utils.stringToMD5(payment);
            user.setPayment(paymentMd5);
        }
        //设置用户初始余额
        user.setUser_money(0.0);
        //用户会员等级  根据余额来评定等级  钻石 打9折，星耀 打8折，王者  打7折
        Double user_money = user.getUser_money();
        if (user_money>=0.0 && user_money<100){
            user.setGrade("钻石");
        }else if (user_money>=100 && user_money<500){
            user.setGrade("星耀");
        }else if (user_money>=500){
            user.setGrade("王者");
        }
        user.setRegister_date(new Date());
        //System.out.println("user = " + user);
        int i=userService.addUser(user);
        return i>0?true:false;
    }

    @RequestMapping("/updateSetUpUserPayment")
    @ResponseBody
    public boolean updateSetUpUserPayment(String payment,HttpServletRequest request){

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        user.setPayment(payment.trim());

        int i = userService.updateSetUpUserPayment(user);

        //System.out.println("payment = " + payment);
        session.setAttribute("user",user);
        return i>0?true:false;

    }

    @RequestMapping("/listByName")
    public String listByName(@RequestParam(defaultValue = "") String name,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "4") Integer pageSize, Model model){
        PageInfo<User> pageInfo=userService.listByName(name,pageNum,pageSize);
        List<User> list = pageInfo.getList();
        /*for (User user : list) {
            Date date = user.getRegister_date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String format = dateFormat.format(date);
            System.out.println("format = " + format);
            model.addAttribute("date",format);
        }*/
        model.addAttribute("page",pageInfo);
        model.addAttribute("name",name);
        //System.out.println("model = " + model);
        return "user/list_user";
    }

    @RequestMapping("/findById")
    @ResponseBody
    public User findeById(Integer id){
        User user = userService.findById(id);
        //System.out.println("user = " + user);
        return user;
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(User user,MultipartFile photo,HttpServletRequest request){

        if (photo!=null && photo.getSize()>0){
            String realPath = request.getServletContext().getRealPath("/user_upload/");
            File file = new File(realPath);
            if (!file.exists()){
                file.mkdir();
            }
            String filename = photo.getOriginalFilename();
            //System.out.println("filename = " + filename);
            String filenameUUID = UUID.randomUUID().toString().replace("-","")+filename.substring(filename.lastIndexOf("."));
            //System.out.println("filenameUUID = " + filenameUUID);
            File file2 = new File(file, filenameUUID);
           /* String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filenameUUID;*/
            try {
                photo.transferTo(file2);
            } catch (IOException e) {
                e.printStackTrace();
            }
            user.setPhotopath("user_upload/"+filenameUUID);
        }

        HttpSession session = request.getSession();
        int i = userService.updateById(user);
        user=userService.findById(user.getId());
        session.setAttribute("user",user);
        return i>0?true:false;
    }
    @RequestMapping("/updateUserAndPassword")
    @ResponseBody
    public boolean updateUserAndPassword(String password,String password1,HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        password = MD5Utils.stringToMD5(password);
        if (password.equals(user.getPassword())){
            password1 = MD5Utils.stringToMD5(password1);
            user.setPassword(password1);
            userService.updateUserAndPassword(user);
            return true;
        }
        return false;
    }

    @RequestMapping("/updateUserPayment")
    @ResponseBody
    public boolean updateUserPayment(HttpServletRequest request,String payment,String payment1){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (payment.equals(user.getPayment())){
            user.setPayment(payment1);
            userService.updateByUserPaymentPassword(user);
            return true;
        }
        //System.out.println("user = " + user);
        return false;
    }


    @RequestMapping("/delById")
    @ResponseBody
    public boolean delById(Integer id){
        return userService.delById(id);
    }



    //用户登录
    @RequestMapping(value = "/loginUser",method = RequestMethod.POST)
    @ResponseBody
    public boolean usernameAndPassword(@RequestParam(defaultValue = "") String username,
                                       @RequestParam(defaultValue = "") String password,HttpServletRequest request){

        password=MD5Utils.stringToMD5(password);
        HttpSession session = request.getSession();
        User user=userService.selectUsernameAndPassword(username,password);
        //System.out.println("user = " + user);
        if (user!=null){
            //登录成功后，清空上一次用户登录时的临时表
            provisionalService.deletes();

            /*每次用户登录之后判断  用户账户金额 从而修改用户的等级  从而打相应的折扣*/
            Double user_money = user.getUser_money();
            if (user_money>=0.0 && user_money<100){
                user.setGrade("钻石");
            }else if (user_money>=100 && user_money<500){
                user.setGrade("星耀");
            }else if (user_money>=500){
                user.setGrade("王者");
            }
            int i = userService.updateUserGrade(user);


            session.setAttribute("user",user);
            session.setAttribute("username",username);
            session.setAttribute("password",password);
            return true;
        }else {
            session.setAttribute("user",null);
            session.setAttribute("username","");
            session.setAttribute("password","");
            return false;
        }
    }

    @RequestMapping("/updateUserRechargeAndMoney")
    @ResponseBody
    public boolean userRechargeAndMoney(String user_money,String payment,HttpServletRequest request){
        Double money = Double.valueOf(user_money);
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if ((user.getPayment()).equals(payment)){
            /*将充值的金额 与账户本身有的金额相加*/
            money=user.getUser_money()+money;
            user = userService.findById(user.getId());
            user.setUser_money(money);
            int i = userService.updateUserRechargeAndMoney(user);
            session.setAttribute("user",user);
            return true;
        }else {
            return false;
        }


    }

}
