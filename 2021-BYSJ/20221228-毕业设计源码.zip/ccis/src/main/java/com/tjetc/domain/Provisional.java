package com.tjetc.domain;

/*
* 用于购物车，转变成订单时，复选框的状态存储的表
* */
public class Provisional {
    private Integer id;
    private Integer user_id;//用户id
    private Integer product_id;//商品id
    private Integer count;//单件商品的数量
    private String myCat_status;//复选框的状态

    private Integer myCart_id;//购物车的中单件商品，对应的购物车中的id  唯一的


    public Provisional() {
    }

    public Provisional(Integer id, Integer user_id, Integer product_id, Integer count, String myCat_status, Integer myCart_id) {
        this.id = id;
        this.user_id = user_id;
        this.product_id = product_id;
        this.count = count;
        this.myCat_status = myCat_status;
        this.myCart_id = myCart_id;
    }

    @Override
    public String toString() {
        return "Provisional{" +
                "id=" + id +
                ", user_id=" + user_id +
                ", product_id=" + product_id +
                ", count=" + count +
                ", myCat_status='" + myCat_status + '\'' +
                ", myCart_id=" + myCart_id +
                '}';
    }

    public Integer getMyCart_id() {
        return myCart_id;
    }

    public void setMyCart_id(Integer myCart_id) {
        this.myCart_id = myCart_id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public String getMyCat_status() {
        return myCat_status;
    }

    public void setMyCat_status(String myCat_status) {
        this.myCat_status = myCat_status;
    }
}
