package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Business;

public interface BusinessService {
    int add(Business business);

    Business selectByCompanies(String companies);

    int updateByBalance(Business business);

    boolean deleteById(Integer id);

    int updateById(Business business);

    Business findById(Integer id);

    PageInfo<Business> selectByBusinessName(String business_name, Integer pageNum, Integer pageSize);
}
