package com.tjetc.domain;

/**
 * 购物车表
 */
public class MyCat {
    private Integer id;
    private Integer user_id;//用户id
    private Integer product_id;//商品id
    private String size;//尺码
    private String patten;//颜色
    private String brand;//商品品牌

    private User user;
    private Product product;

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }


    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getPatten() {
        return patten;
    }

    public void setPatten(String patten) {
        this.patten = patten;
    }

    @Override
    public String toString() {
        return "MyCat{" +
                "id=" + id +
                ", user_id=" + user_id +
                ", product_id=" + product_id +
                ", size='" + size + '\'' +
                ", patten='" + patten + '\'' +
                ", brand='" + brand + '\'' +
                ", user=" + user +
                ", product=" + product +
                '}';
    }

    public MyCat(Integer id, Integer user_id, Integer product_id, String size, String patten, String brand, User user, Product product) {
        this.id = id;
        this.user_id = user_id;
        this.product_id = product_id;
        this.size = size;
        this.patten = patten;
        this.brand = brand;
        this.user = user;
        this.product = product;
    }

    public MyCat(Integer id, Integer user_id, Integer product_id, String size, String patten, User user, Product product) {
        this.id = id;
        this.user_id = user_id;
        this.product_id = product_id;
        this.size = size;
        this.patten = patten;
        this.user = user;
        this.product = product;
    }

    public MyCat(Integer id, Integer user_id, Integer product_id, User user, Product product) {
        this.id = id;
        this.user_id = user_id;
        this.product_id = product_id;
        this.user = user;
        this.product = product;
    }

    public MyCat() {
    }
}
