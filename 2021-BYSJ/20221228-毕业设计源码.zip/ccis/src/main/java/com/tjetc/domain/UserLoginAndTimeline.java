package com.tjetc.domain;

/*
* Timeline:时间线，记录用户的登录时间
* */

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

public class UserLoginAndTimeline {

    private Integer id;
    private Integer uid;
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    /*@JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")*/
    private Date userLoginDate;

    public UserLoginAndTimeline() {
    }

    public UserLoginAndTimeline(Integer id, Integer uid, Date userLoginDate) {
        this.id = id;
        this.uid = uid;
        this.userLoginDate = userLoginDate;
    }

    @Override
    public String toString() {
        return "UserLoginAndTimeline{" +
                "id=" + id +
                ", uid=" + uid +
                ", userLoginDate=" + userLoginDate +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Date getUserLoginDate() {
        return userLoginDate;
    }

    public void setUserLoginDate(Date userLoginDate) {
        this.userLoginDate = userLoginDate;
    }
}
