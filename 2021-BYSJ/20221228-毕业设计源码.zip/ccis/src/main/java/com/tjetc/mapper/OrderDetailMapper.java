package com.tjetc.mapper;

import com.tjetc.domain.OrderDetail;

import java.util.List;
import java.util.Map;

public interface OrderDetailMapper {
    int add(OrderDetail orderDetail);

    List<OrderDetail> listByName(String name);

    OrderDetail findById(Integer id);

    int updateById(OrderDetail orderDetail);

    int deleById(Integer id);

    List<OrderDetail> listByNameS(Map<String, Object> map);

    List<OrderDetail> selectOrderDetail();

}
