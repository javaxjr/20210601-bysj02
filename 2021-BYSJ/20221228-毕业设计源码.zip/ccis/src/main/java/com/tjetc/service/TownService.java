package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Town;

import java.util.List;
import java.util.Map;

public interface TownService {
    int add(Town town);

    PageInfo<Town> selectByName(Map<String, Object> map, Integer pageNum, Integer pageSize);

    Town selectById(Integer id);

    int updateById(Town town);

    int delById(Integer id);

    List<Town> selectByTTownAndCityCounty(String city_county);
}
