package com.tjetc.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Admin;
import com.tjetc.mapper.AdminMapper;
import com.tjetc.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AdminMapper adminMapper;
    public int add(Admin admin) {
        return adminMapper.add(admin);
    }

    public Admin findById(Integer id) {
        return adminMapper.findById(id);
    }

    public PageInfo<Admin> listByName(String name, Integer pageName, Integer pageSize) {

       Map<String,Object> map = new HashMap<String,Object>();
        PageHelper.startPage(pageName,pageSize);
        List<Admin> list=adminMapper.listByName(map);
        PageInfo<Admin> pageInfo = new PageInfo<Admin>(list);
        return pageInfo;
    }

    public int updateById(Admin admin) {
        return adminMapper.updateById(admin);
    }

    public boolean delById(Integer id) {
        int i=adminMapper.delById(id);
        return i>0?true:false;
    }

    public Admin selectByUsernameAndPassword(Map<String, Object> map) {
        return adminMapper.selectByUsernameAndPassword(map);
    }

    public int updateAdminPasswordById(Admin admin) {
        return adminMapper.updateAdminPasswordById(admin);
    }

    @Override
    public Admin selectUserNameByPhone(Map<String,Object> map) {
        return adminMapper.selectUserNameByPhone(map);
    }


    @Override
    public List<Map<String, String>> selectByMapProduct(JSONObject jsonObject) {

        JSONObject mapList = adminMapper.selectByMapProduct(jsonObject);

        System.out.println("mapList = " + mapList);

        return  null;
    }

}
