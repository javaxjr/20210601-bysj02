package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.CityCounty;
import com.tjetc.mapper.CityCountyMapper;
import com.tjetc.service.CityCountyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CityCountyServiceImpl implements CityCountyService {

    @Autowired
    private CityCountyMapper cityCountyMapper;
    public boolean add(CityCounty cityCounty) {
        return (cityCountyMapper.add(cityCounty))>0?true:false;
    }

    public PageInfo<CityCounty> selectByName(Map<String, Object> map, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<CityCounty> list= cityCountyMapper.selectByName(map);
        PageInfo<CityCounty> pageInfo = new PageInfo<CityCounty>(list);
        return pageInfo;
    }

    public CityCounty selectById(Integer id) {
        return cityCountyMapper.selectById(id);
    }

    public boolean updateById(CityCounty cityCounty) {
        return (cityCountyMapper.updateById(cityCounty))>0?true:false;
    }

    public boolean delById(Integer id) {
        return (cityCountyMapper.delById(id))>0?true:false;
    }

    public List<CityCounty> selectByCtyCounty(String provinces_cities) {
        return cityCountyMapper.selectByCtyCounty(provinces_cities);
    }
}
