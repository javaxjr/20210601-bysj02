package com.tjetc.service.impl;

import com.tjetc.domain.MyCat;
import com.tjetc.mapper.MyCatMapper;
import com.tjetc.service.MyCatService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class MyCatServiceImpl implements MyCatService {
    @Autowired
    private MyCatMapper myCatMapper;

    public List<MyCat> selectByMyCat(int user_id) {
        return myCatMapper.selectByMyCat(user_id);
    }

    public int addByMyCat(Map<String,Object> map) {
        return myCatMapper.addByMyCat(map);
    }

    public int delById(Integer id) {
        return myCatMapper.delById(id);
    }

    public MyCat selectUIdByPId(Map<String,Object> map) {
        return myCatMapper.selectUIdByPId(map);
    }

    public int delByUIdAndPId(MyCat myCat) {
        return myCatMapper.delByUIdAndPId(myCat);
    }

    public MyCat selectByMyCatId(Integer myCart_id) {
        return myCatMapper.selectByMyCartId(myCart_id);
    }

    public MyCat selectByPidAndUid(MyCat myCat) {
        return myCatMapper.selectByPidAndUid(myCat);
    }

    public MyCat findByMyCartId(Integer id) {
        return myCatMapper.findByMyCartId(id);
    }

    public int updateMyCart(MyCat myCat) {
        return myCatMapper.updateMyCart(myCat);
    }
}
