package com.tjetc.mapper;

import com.tjetc.domain.Provisional;

import java.util.List;

public interface ProvisionalMapper {
    int add(Provisional provisional);

    int delByPIdAndUId(Provisional provisional);

    List<Provisional> selectByProvisional(Integer user_id);

    void deletes();

    List<Provisional> selectByProvisional2();

    List<Provisional> selectByUserId(Integer id);

    int deleteByMyCartId(Integer myCart_id);

    int delByUid(Integer uid);
}
