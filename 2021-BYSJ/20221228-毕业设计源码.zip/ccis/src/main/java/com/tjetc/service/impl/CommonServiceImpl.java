package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.*;
import com.tjetc.mapper.*;
import com.tjetc.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class CommonServiceImpl implements CommonService {
    @Autowired
    private AcknowledgementOrderMapper acknowledgementOrderMapper;
    @Autowired
    private AddressMapper addressMapper;
    @Autowired
    private AddressRegionMapper addressRegionMapper;
    @Autowired
    private AdminMapper adminMapper;
    @Autowired
    private BusinessMapper businessMapper;
    @Autowired
    private CityCountyMapper cityCountyMapper;
    @Autowired
    private CollectionNowMapper collectionNowMapper;
    @Autowired
    private EvaluationMapper evaluationMapper;
    @Autowired
    private MyCatMapper myCatMapper;
    @Autowired
    private OrderMapper orderMapper;
    @Autowired
    private OrderDetailMapper orderDetailMapper;
    @Autowired
    private ProductMapper productMapper;
    @Autowired
    private ProvisionalMapper provisionalMapper;
    @Autowired
    private TownMapper townMapper;
    @Autowired
    private TypeMapper typeMapper;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private UserLoginAndTimelineMapper userLoginAndTimelineMapper;


    @Override
    public <T> int addSave(Map<String, Object> map, T t) {
        if (t instanceof AcknowledgementOrder){
            AcknowledgementOrder acknowledgementOrder = (AcknowledgementOrder) map.get("acknowledgementOrder");
            return acknowledgementOrderMapper.addSubmit(acknowledgementOrder);
        }else if (t instanceof Address){
            Address address = (Address) map.get("address");
            return addressMapper.addAddress(address);
        }else if (t instanceof AddressRegion){
            AddressRegion addressRegion = (AddressRegion) map.get("addressRegion");
            return addressRegionMapper.add(addressRegion);
        }else if (t instanceof Admin){
            Admin admin = (Admin) map.get("admin");
            return adminMapper.add(admin);
        }else if (t instanceof Business){
            Business business = (Business) map.get("business");
            return businessMapper.add(business);
        }else if (t instanceof CityCounty){
            CityCounty cityCounty = (CityCounty) map.get("cityCounty");
            return cityCountyMapper.add(cityCounty);
        }else if (t instanceof CollectionNow){
            CollectionNow collectionNow = (CollectionNow) map.get("collectionNow");
            return collectionNowMapper.addCollectionNow(collectionNow);
        }else if (t instanceof Evaluation){
            Evaluation evaluation = (Evaluation) map.get("evaluation");
            return evaluationMapper.addEvaluation(evaluation);
        }else if (t instanceof MyCat){
            MyCat myCat = (MyCat) map.get("myCat");
            return myCatMapper.addByMyCat(map);
        }else if (t instanceof Order){
            Order order = (Order) map.get("order");
            return orderMapper.addSettleAccounts(order);
        }else if (t instanceof OrderDetail){
            OrderDetail orderDetail = (OrderDetail) map.get("orderDetail");
            return orderDetailMapper.add(orderDetail);
        }else if (t instanceof Product){
            Product product = (Product) map.get("product");
            return productMapper.add(product);
        }else if (t instanceof Town){
            Town town = (Town) map.get("Town");
            return townMapper.add(town);
        }else if (t instanceof Type){
            Type type = (Type) map.get("type");
            return typeMapper.add(type);
        }else if (t instanceof User){
            User user = (User) map.get("user");
            return userMapper.addUser(user);
        }else if (t instanceof UserLoginAndTimeline){
            userLoginAndTimelineMapper.addUserTimeline((UserLoginAndTimeline)map.get("userLoginAndTimeline"));
        }

        return 0;
    }

    @Override
    public <T> PageInfo<T> selectByName(Map<String, Object> map, Integer pageNum, Integer pageSize, T t) {
        PageHelper.startPage(pageNum,pageSize);
        List<T> list = null;
        if (t instanceof Admin){
            list= (List<T>) adminMapper.listByName(map);
        }else if (t instanceof Address){
            list= (List<T>) addressMapper.listByAndName(map);
        }else if (t instanceof AcknowledgementOrder){
            list = (List<T>) acknowledgementOrderMapper.selectByOrderStatus((String) map.get("order_status"));
        }else if (t instanceof AddressRegion){
            list= (List<T>) addressRegionMapper.listByAndName(map);
        }else if (t instanceof Business){
            list= (List<T>)businessMapper.selectByBusinessName((String) map.get("business_name"));
        }else if (t instanceof CityCounty){
            list= (List<T>)cityCountyMapper.selectByName(map);
        }else if (t instanceof CollectionNow){
            list= (List<T>)collectionNowMapper.selectByUserCollectionNow((Integer) map.get("user_id"));
        }else if (t instanceof Evaluation){
            list= (List<T>)evaluationMapper.selectByIdAndOrderDetail((Integer) map.get("product_id"));
        }else if (t instanceof MyCat){
            list= (List<T>)myCatMapper.selectUIdByPId(map);
        }else if (t instanceof Order){
            list= (List<T>)orderMapper.selectByMyCartId(map);
        }else if (t instanceof OrderDetail){
            list= (List<T>)orderDetailMapper.listByNameS(map);
        }else if (t instanceof Product){
            list= (List<T>)productMapper.selectSearchByType((String) map.get("type"));
        }else if (t instanceof Town){
            list= (List<T>)townMapper.selectByName(map);
        }else if (t instanceof Type){
            list= (List<T>)typeMapper.listByName(map);
        }else if (t instanceof User){
            list= (List<T>)userMapper.selectByUserObject(map);
        }else if (t instanceof UserLoginAndTimeline){
            list= (List<T>)userLoginAndTimelineMapper.selectUserLoginAndTimelineByUid((Integer) map.get("userId"));
        }
        PageInfo<T> pageInfo = new PageInfo(list);
        return pageInfo;
    }

    @Override
    public <T> int updateCommon(Map<String, Object> map, T t) {
        return 0;
    }

    @Override
    public <T> int deleteCommonById(Object object, T t) {
        return 0;
    }
}
