package com.tjetc.mapper;

import com.tjetc.domain.UserLoginAndTimeline;

import java.util.List;

public interface UserLoginAndTimelineMapper {
    void addUserTimeline(UserLoginAndTimeline usertimeline);

    List<UserLoginAndTimeline> selectUserLoginAndTimelineByUid(Integer userId);
}
