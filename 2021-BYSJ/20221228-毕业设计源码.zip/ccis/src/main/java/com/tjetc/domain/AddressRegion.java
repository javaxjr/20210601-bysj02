package com.tjetc.domain;

import com.fasterxml.jackson.annotation.JsonTypeInfo;

import java.util.UUID;

/*
* 省份区域表
* */
public class AddressRegion {
    private Integer id;
    private String provinces_cities;//省份

    private String uuid= UUID.randomUUID().toString().replaceAll("-","");


    public AddressRegion() {
    }

    public AddressRegion(Integer id, String provinces_cities) {
        this.id = id;
        this.provinces_cities = provinces_cities;
    }

    @Override
    public String toString() {
        return "AddressRegion{" +
                "id=" + id +
                ", provinces_cities='" + provinces_cities + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProvinces_cities() {
        return provinces_cities;
    }

    public void setProvinces_cities(String provinces_cities) {
        this.provinces_cities = provinces_cities;
    }
}
