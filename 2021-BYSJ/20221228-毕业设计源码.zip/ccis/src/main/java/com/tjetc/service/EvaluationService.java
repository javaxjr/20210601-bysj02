package com.tjetc.service;

import com.tjetc.domain.Evaluation;

import java.util.List;

public interface EvaluationService {
    int addEvaluation(Evaluation evaluation);

    List<Evaluation> selectByIdAndOrderDetail(Integer product_id);
}
