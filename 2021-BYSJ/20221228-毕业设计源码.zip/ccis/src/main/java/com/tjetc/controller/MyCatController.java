package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.*;
import com.tjetc.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/myCat")

public class MyCatController {

    @Autowired
    private ProductService productService;
    @Autowired
    private MyCatService myCatService;
    @Autowired
    private ProvisionalService provisionalService;
    @Autowired
    private AcknowledgementOrderService acknowledgementOrderService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private OrderDetailService orderDetailService;

    @RequestMapping("/add")
    @ResponseBody
    public boolean add(Integer user_id,Integer product_id,String patten,String size,String brand){
        Map<String,Object> map=new HashMap<String,Object>();
        map.put("user_id",user_id);
        map.put("product_id",product_id);
        map.put("patten",patten);
        map.put("size",size);
        map.put("brand",brand);
        MyCat myCat=myCatService.selectUIdByPId(map);
        int i=0;
        if (myCat==null && user_id!=null && product_id!=null){
           i=myCatService.addByMyCat(map);
        }
        return i>0?true:false;
    }

    /*查询购物车中是否已有已添加的物品，若有 则无需再添加*/
    @RequestMapping("/selectByPidAndUid")
    @ResponseBody
    public boolean selectByPidAndUid(MyCat myCat,HttpServletRequest request){
        //String userId = request.getParameter("product_id");
        //System.out.println("userId = " + userId);
        myCat = myCatService.selectByPidAndUid(myCat);
        return myCat!=null?true:false;
    }

    @RequestMapping("/selectByProduct")
    @ResponseBody
    public PageInfo<Product> selectByProduct(@RequestParam(defaultValue = "1") Integer pageNum,
                                             @RequestParam(defaultValue = "6") Integer pageSize){

        /*每次加载数据时，，删除尚未提交的订单*/
        String order_status="未提交";
        List<AcknowledgementOrder> acknowledgementOrders = acknowledgementOrderService.selectByOrderStatus(order_status);
        for (AcknowledgementOrder acknowledgementOrder : acknowledgementOrders) {
            Integer order_id = acknowledgementOrder.getOrder_id();
            /*删除订单表中未提交的订单信息*/
            int i = orderService.deleteById(order_id);
            /*删除 订单是否提交的状态  未提交对应的信息*/
            int j = acknowledgementOrderService.deleteById(acknowledgementOrder.getId());
        }

        PageInfo<Product> pageInfo = productService.selectByProduct(pageNum, pageSize);
        return pageInfo;

    }

    @RequestMapping("/selectByMyCat")
    public String selectByMyCat(Model model, HttpServletRequest request){

        //每次刷新购物车页面的时候，临时表都会清空
        provisionalService.deletes();
        HttpSession session = request.getSession();
        List<MyCat> list=null;
        User user = (User) session.getAttribute("user");
        if (user!=null){
            int user_id=user.getId();
            list= myCatService.selectByMyCat(user_id);
        }
        System.out.println("user = " + user);
        model.addAttribute("list",list);
        return "my_cat";
    }

    @RequestMapping("/findByMyCartId")
    @ResponseBody
    public Map<String,Object> findByMyCartId(Integer id){

        Map<String,Object> map = new HashMap<String, Object>();
        List<OrderDetail> orderDetailList = orderDetailService.selectOrderDetail();
        MyCat myCat = myCatService.findByMyCartId(id);
        map.put("orderDetailList",orderDetailList);
        map.put("myCat",myCat);
        return map;
    }

    @RequestMapping("/updateMyCartById")
    @ResponseBody
    public boolean updateMyCartById(MyCat myCat){
        System.out.println("myCat = " + myCat);
        int i = myCatService.updateMyCart(myCat);
        return i>0?true:false;
    }

    //在购物车中批量删除
    @RequestMapping("/deletesMyCatById")
    @ResponseBody
    public boolean deletesMyCatById(Integer id){

        List<Provisional> provisionalList = provisionalService.selectByProvisional2();
        for (Provisional provisional : provisionalList) {
            int i = myCatService.delById(provisional.getMyCart_id());
        }
        provisionalService.deletes();
        return true;
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean del(Integer id){
        int i=myCatService.delById(id);
        return i>0?true:false;
    }


}
