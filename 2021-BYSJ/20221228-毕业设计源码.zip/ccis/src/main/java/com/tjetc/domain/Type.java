package com.tjetc.domain;

import java.util.List;

/**
 * 商品类别
 */
public class Type {
    private Integer id;//类别编号
    private String product_type;//商品类别
    private List<Product> list;

    public Type() {
    }

    public Type(Integer id, String product_type, List<Product> list) {
        this.id = id;
        this.product_type = product_type;
        this.list = list;
    }

    public Type(Integer id, String product_type) {
        this.id = id;
        this.product_type = product_type;
    }

    @Override
    public String toString() {
        return "Type{" +
                "id=" + id +
                ", product_type='" + product_type + '\'' +
                ", list=" + list +
                '}';
    }

    public List<Product> getList() {
        return list;
    }

    public void setList(List<Product> list) {
        this.list = list;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProduct_type() {
        return product_type;
    }

    public void setProduct_type(String product_type) {
        this.product_type = product_type;
    }
}