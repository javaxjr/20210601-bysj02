package com.tjetc.service;

import com.tjetc.domain.Provisional;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

public interface ProvisionalService {
    int add(Provisional provisional);

    int delByPIdAndUId(Provisional provisional);

    List<Provisional> selectByProvisional(Integer user_id);

    void deletes();

    List<Provisional> selectByProvisional2();

    List<Provisional> selectByUserId(Integer id);

    int deleteByMyCartId(Integer id);

    int delByUid(Integer id);

}
