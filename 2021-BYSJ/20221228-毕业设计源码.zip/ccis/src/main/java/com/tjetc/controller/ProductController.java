package com.tjetc.controller;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.*;
import com.tjetc.service.*;
import com.tjetc.util.ErrorEnumMessage;
import com.tjetc.util.ExcelUtils;
import com.tjetc.util.WebMapPageResult;
import com.tjetc.util.excel.DownloadExcel;
//import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

//@Slf4j
@Controller
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;
    @Autowired
    private TypeService typeService;
    @Autowired
    private UserService userService;
    @Autowired
    private OrderDetailService orderDetailService;
    @Autowired
    private AcknowledgementOrderService acknowledgementOrderService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private EvaluationService evaluationService;
    @Autowired
    private ProvisionalService provisionalService;
    @Autowired
    private UserLoginAndTimelineService userLoginAndTimelineService;

    @Autowired
    private CommonService commonService;

    @RequestMapping("/selectByProductType")
    @ResponseBody
    public List<Type> selectByProductType(){
        return typeService.selectByProductType();
    }



    @RequestMapping("/add")
    @ResponseBody
    public boolean add(Product product, MultipartFile photo, HttpServletRequest request){
        //System.out.println("product = " + product);
        if (photo!=null && photo.getSize()>0) {
            String realPath = request.getServletContext().getRealPath("/upload/");
            File file = new File(realPath);
            if (!file.exists()) {
                file.mkdir();
            }

            SimpleDateFormat sdf = new SimpleDateFormat();
            Date date = new Date();
            String pathName = sdf.format(date);

            String filename = photo.getOriginalFilename();
            String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filename;
            File file2 = new File(file, uuidFileName);
            //System.out.println("uuidFileName = " + uuidFileName);
            product.setPhotopath("upload/"+uuidFileName);
            try {
                photo.transferTo(file2);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        int i=productService.add(product);
        return i>0?true:false;
    }

    @RequestMapping("/selectMap")
    @ResponseBody
    public PageInfo selectMap(String str){

        Map map = new HashMap<String,Object>();

        map.put("type",str);
        PageInfo<Admin> pageInfo = commonService.selectByName(map, 1, 5, new Product());

        System.out.println("pageInfo = " + pageInfo);

        return pageInfo;
    }

    //批量上传数据   单一版
    @RequestMapping("/addProductUploadExcel")
    @ResponseBody
    public Map<String,Object> addProductUploadExcel(MultipartFile file,Product product){

       // System.out.println("product = " + product);
        Map<String,Object> map = new HashMap<String, Object>();
       String msg="";
        if (file!=null){
            Integer i = productService.addProductUploadExcel(file);
            if (i>0){
                msg="上传成功";
            }else {
                msg="上传失败、文件格式不正确，或者文件已损坏";
            }
        }else {
            msg="上传失败、请检查您的文件格式是否有误";
        }
        map.put("msg",msg);
        return map;
    }

    //批量导入商品信息   使用泛型方法 实现多种化
    @RequestMapping("/uploadExcelDistributeAccess")
    @ResponseBody
    public boolean uploadExcelDistributeAccess(MultipartFile file,Product product){

        //System.out.println("file = " + file);

        List<Product> list = productService.saveExcelFile(file,new Product());

        //System.out.println("list = " + list);
        //CollectionUtils:用来比较
        if (!CollectionUtils.isEmpty(list)){
            return true;
        }else {
            // 比较错误信息  并从枚举类中获取  相对应信息
            String errors =  ExcelUtils.getErrors();
            if (errors.isEmpty()){
                errors = ErrorEnumMessage.EMPITYTEMPLATE.getErrorDescribe();
            }
            return false;
        }

    }


    //下载
    @RequestMapping("/downloadProduct")
    @ResponseBody
    public boolean downloadProduct(String url) throws Exception {

        List<Product> productList = productService.selectProduct();
        //List list = CreateSimpleExcelToDisk.getProduct();
        productService.productExcel(productList,url);
        return true;
    }

    //下载商品导入模板
    @RequestMapping(value = "downloadExcel",method = RequestMethod.GET)
    public void download(HttpServletRequest request, HttpServletResponse response,String filename) throws IOException {
        DownloadExcel.download(request,response,filename);
    }


    @RequestMapping("/listByName")
    @ResponseBody
    public PageInfo<Product> listByName(@RequestParam(defaultValue = "") String name,
                                        @RequestParam(defaultValue = "1") Integer pageNum,
                                        @RequestParam(defaultValue = "4") Integer pageSize){
        PageInfo<Product> pageInfo=productService.listByName(name,pageNum,pageSize);
        //System.out.println("pageInfo = " + pageInfo);
        return pageInfo;
    }

    /*点击搜索按钮时查询*/
    @RequestMapping("/selectSearchByName")
    public String selectSearchByName(@RequestParam(defaultValue = "") String type,
                                    @RequestParam(defaultValue = "1") Integer pageNum,
                                    @RequestParam(defaultValue = "50") Integer pageSize,Model model){

        PageInfo<Product> pageInfo = productService.selectSearchByName(type,pageNum,pageSize);

        //System.out.println("pageInfo = " + pageInfo);

        model.addAttribute("type",type);
        model.addAttribute("page",pageInfo);

        return "/product/index2_product";
    }

    /*往搜索文本框中输入文本时触发*/
    @RequestMapping("/selectProductByType")
    @ResponseBody
    public List<Type> selectProductByType(@RequestParam(defaultValue = "") String type){

        if ("".equals(type.trim())){
            type="@#$$%$#GFDD";
        }
        List<Type> typeList = typeService.selectProductByType(type);
        return typeList;
    }

    /*往文本框中输入 文字后  获取到的相关信息  并点击某件类型*/
    @RequestMapping("/selectByTypeById")
    public String selectByTypeById(Integer id,Model model,HttpServletRequest request){

        Type type = typeService.findById(id);
        String productType = type.getProduct_type();

        /*HttpSession session = request.getSession();
        session.setAttribute("productType",productType);*/

        PageInfo<Product> pageInfo = productService.selectSearchByName(productType, 1, 50);
        //System.out.println("pageInfo辅导辅导 = " + pageInfo);
        model.addAttribute("productType",productType);
        model.addAttribute("page",pageInfo);

        return "/product/index2_product";
    }

    /*在第二商品页面中进行查询商品*/
    @RequestMapping("/selectProductByNameIndex2")
    public String selectProductByNameIndex2(@RequestParam(defaultValue = "")String name,Model model,HttpServletRequest request){

        /**/
        /*HttpSession session = request.getSession();
        String productType = (String) session.getAttribute("productType");*/

        /*通过商品类型查询完成之后   再根据商品名称去查询*/
        PageInfo<Product> pageInfo = productService.listByName(name, 1, 50);
        model.addAttribute("page",pageInfo);
        model.addAttribute("productType",name);
        return "/product/index2_product";
    }

    @RequestMapping("/selectProduct")
    @ResponseBody
    public PageInfo<Product> selectProduct(@RequestParam(defaultValue = "1") Integer pageNum,
                                       @RequestParam(defaultValue = "25") Integer pageSize,HttpServletRequest request){

        HttpSession session = request.getSession();

        /*每次加载数据时，，删除尚未提交的订单*/
        String order_status="未提交";
        List<AcknowledgementOrder> acknowledgementOrders = acknowledgementOrderService.selectByOrderStatus(order_status);

        if (acknowledgementOrders!=null && acknowledgementOrders.size()>0){
            for (AcknowledgementOrder acknowledgementOrder : acknowledgementOrders) {
                Integer order_id = acknowledgementOrder.getOrder_id();
                /*删除订单表中未提交的订单信息*/
                int i = orderService.deleteById(order_id);
                /*删除 订单是否提交的状态  未提交对应的信息*/
                int j = acknowledgementOrderService.deleteById(acknowledgementOrder.getId());
            }
        }

        PageInfo<Product> pageInfo=productService.listByName("",pageNum,pageSize);
        List<Product> list = productService.selectProduct();
        //System.out.println("list = " + list);

        /*设置用户未登录时   error的状态*/
        session.setAttribute("error","");
        User user = (User) session.getAttribute("user");
        //删除订单临时表中的相关用户的信息
        if (user!=null){
            List<Provisional> provisionalList = provisionalService.selectByProvisional(user.getId());
            if (provisionalList.size()>0){
                for (Provisional provisional : provisionalList) {
                    provisionalService.delByPIdAndUId(provisional);
                }
            }
           // int i =  provisionalService.delByUid(user.getId());
        }
        return pageInfo;
    }

    //用户刚打开网页时  验证7天免登录
    @RequestMapping("/selectProductsByIndex")
    public String selectProductsByIndex(HttpServletRequest request){
        HttpSession session = request.getSession();
        if (session.getAttribute("user")==null){
            //读取cookie
            Cookie[] cookies = request.getCookies();
            if (cookies!=null){
                for (Cookie cookie : cookies) {
                    if ("username".equals(cookie.getName())){
                        session.setAttribute("username",cookie.getValue());
                        session.setAttribute("subtotal",0.0);
                        User user2 = userService.findByUsername(cookie.getValue());
                        if (user2!=null){
                            session.setAttribute("user",user2);
                            UserLoginAndTimeline usertimeline = new UserLoginAndTimeline();
                            usertimeline.setUid(user2.getId());
                            usertimeline.setUserLoginDate(new Date());
                            userLoginAndTimelineService.addUserTimeline(usertimeline);
                        }
                    }
                }
            }
        }

        System.out.println("***************************启动完成**********************");
        System.out.println("***************************启动完成**********************");
        System.out.println("***************************启动完成**********************");
        System.out.println("***************************启动完成**********************");
        System.out.println("***************************启动完成**********************");
        System.out.println("***************************启动完成**********************");

        System.out.println();
        System.out.println();

        System.out.println("\"///////////////////////////////////////////////////////////\\n\"+\n" +
                "\"//                      _ao0oo_                          //\\n\"+\n" +
                "\"//                     o8888888o                         //\\n\"+\n" +
                "\"//                     88* , *88                         //\\n\"+\n" +
                "\"//                     (| '_' |)                         //\\n\"+\n" +
                "\"//                     0\\\\  = /0                         //\\n\"+\n" +
                "\"//                  ——/'——‘——                        //\\n\"+\n" +
                "\"//                ,`  \\\\\\\\|    |// ‘,                    //\\n\"+\n" +
                "\"//                /  \\\\\\\\||| : |||  \\\\                   //\\n\"+\n" +
                "\"//               /   _|||| -:- |||- \\\\                   //\\n\"+\n" +
                "\"//               |    |\\\\\\\\\\\\ - /// |  |                 //\\n\"+\n" +
                "\"//               | \\\\_| ''\\\\——/'' |  |                  //\\n\"+\n" +
                "\"//               \\\\ .-\\\\_ '_'  ___/-.  /                 //\\n\"+\n" +
                "\"//              ___'. .'  /-.-\\\\`. .___                  //\\n\"+\n" +
                "\"//            .\\'\\' '<  '._\\\\_<|>_/_.` >'\\'.             //\\n\"+\n" +
                "\"//           | | : `_ \\\\ '.:\\\\ _ /' :. '/-.:||           //\\n\"+\n" +
                "\"//           \\\\ \\\\ `-.  \\\\_ __\\\\ /__ _  .-` //           //\\n\"+\n" +
                "\"//        =======`-.___`-.___\\\\____/___.-`__.=`=====     //\\n\"+\n" +
                "\"//                       '==========='                   //\\n\"+\n" +
                "\"//       ********************************************    //\\n\"+\n" +
                "\"//            佛祖保佑        永不宕机       永无bug        //\\n\"+\n" +
                "\"//                                                       //\\n\"+\n" +
                "\"///////////////////////////////////////////////////////////\\n\");*/");

        System.out.println("佛祖保佑不出错");

        //this.startTest();

        return "index";
    }

    private void startTest() {

        System.out.println("佛祖保佑不出错");

        List<String> list = productService.selectProvince();

        //将集合对像list 分别进行正序和反序输出
        System.out.println();
        System.out.println();
        System.out.println();
        System.out.println("正序list = " + list.toString());
        Collections.reverse(list);
        System.out.println("反序list = " + list.toString());
        Collections.reverse(list);
        System.out.println("恢复初始状态="+list);

        System.out.println("---------------------------");

        //(1)字符串集合转换成为数组
        Object[] listArray = list.toArray();
        //System.out.println("方法（1） = " + Arrays.toString(listArray));

        //(2)
        String[] strings2 = list.toArray(new String[list.size()]);
        System.out.println("方法（2） = " +Arrays.toString(strings2));

        //(3)
        String[] strings3 = new String[list.size()];
        //System.out.println("方法（3） = " +Arrays.toString(strings3));
        System.out.println("-------------将数据集合转换成数组后，对其进行排序-----------");
        System.out.println("使用冒泡排序算法进行排序");
        System.out.println("排序前：对strings2进行排序");

        for (String s : strings2) {
            System.out.print(s+" ");
        }

        System.out.println();
        //冒泡排序
        String tem;
        //外层排序
        for (int i=0;i<strings2.length;i++){
            //里层控制轮数
            for (int j=0;j<strings2.length-i-1;j++){
                if (Integer.parseInt(strings2[j])>Integer.parseInt(strings2[j+1])){
                    tem=strings2[j];
                    strings2[j]=strings2[j+1];
                    strings2[j+1]=tem;
                }
            }
        }
        System.out.println("数组按冒泡排序升序排序为：");
        for (String s : strings2) {
            System.out.print(s+" ");
        }

        System.out.println();
        System.out.println();

        //数组转集合(方法1)
        List<String> asList = Arrays.asList(strings2);
/*
            此时返回的ArrayList是Arrays的一个私有静态内部类，
            可以遍历查询，但是不可以像普通集合那样增删元素
         */
        System.out.println("asList = " + asList.toString());

        ArrayList<String> strings = new ArrayList<String>(asList);

    }


    @RequestMapping("/selectByIdAndOrderDetail")
    //@ResponseBody
    public String selectByIdAndOrderDetail(Integer product_id,Model model,HttpServletRequest request){
        HttpSession session = request.getSession();
        Product product = productService.selectByIdAndOrderDetail(product_id);
        /*查询商品详情表中的所有数据  从而实现选择下拉的效果*/
        List<OrderDetail> list=orderDetailService.selectOrderDetail();
        model.addAttribute("product",product);
        model.addAttribute("list",list);
        User user = (User) session.getAttribute("user");
        if (!"".equals(user)){
            model.addAttribute("user",user);
        }
        List<Evaluation> evaluationList = evaluationService.selectByIdAndOrderDetail(product_id);
        //System.out.println("evaluationList = " + evaluationList);
        model.addAttribute("evaluationList",evaluationList);

        return "/product/product_single";
    }

    //使用layui实现数据的查询
    @RequestMapping("/selectProductByNameAndLayui")
    @ResponseBody
    public WebMapPageResult selectProductByNameAndLayui(@RequestParam(defaultValue = "") String name,HttpServletRequest request){

        Integer pageNum = Integer.parseInt(request.getParameter("page"));
        Integer pageSize = Integer.parseInt(request.getParameter("limit"));

        PageInfo<Product> pageInfo = productService.listByName(name, pageNum, pageSize);

        return WebMapPageResult.success().setData(pageInfo.getList()).setCount(pageInfo.getTotal());
    }

    @RequestMapping("/findById")
    public String findById(Integer id, Model model){
        Product product = productService.findById(id);
        model.addAttribute("product",product);
        return "/product/update";
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(Product product,MultipartFile photo,HttpServletRequest request){
        //System.out.println("product = " + product);
        if (photo!=null && photo.getSize()>0) {
            String realPath = request.getServletContext().getRealPath("/upload/");
            File file = new File(realPath);
            if (!file.exists()) {
                file.mkdir();
            }
            String filename = photo.getOriginalFilename();
            String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filename;
            File file2 = new File(file, uuidFileName);
           // System.out.println("uuidFileName = " + uuidFileName);
            product.setPhotopath("upload/"+uuidFileName);
            try {
                photo.transferTo(file2);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        int i=productService.updateById(product);
        return i>0?true:false;
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean deleteById(Integer id){
        return (productService.deleteById(id))>0?true:false;
    }



}
