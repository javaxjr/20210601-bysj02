package com.tjetc.domain;

import lombok.Data;

/*
* People：人  用户和管理员的父类   有着相同的属性信息
* */
@Data
public class People {
    private Integer id;
    private String name;//管理员姓名
    private String username;//用户名
    private String password;//登录密码
    private Integer age;//年龄
    private String sex;//性别
    private String phone;//联系方式
    private String photopath;//美图

    public People() {
    }

    @Override
    public String toString() {
        return "People{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", age=" + age +
                ", sex='" + sex + '\'' +
                ", phone='" + phone + '\'' +
                ", photopath='" + photopath + '\'' +
                '}';
    }

}
