package com.tjetc.domain;

/**
 * 商品详情表
 */
public class OrderDetail {

    private int id;//编号
    private String brand;//品牌名称
    private String size;//尺码
    private String patten;//颜色
    private String year;//年份
    private String target;//适用对象


    public OrderDetail() {
    }


    @Override
    public String toString() {
        return "OrderDetail{" +
                "id='" + id + '\'' +
                ", brand='" + brand + '\'' +
                ", size='" + size + '\'' +
                ", patten='" + patten + '\'' +
                ", year='" + year + '\'' +
                ", target='" + target + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getPatten() {
        return patten;
    }

    public void setPatten(String patten) {
        this.patten = patten;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }



}
