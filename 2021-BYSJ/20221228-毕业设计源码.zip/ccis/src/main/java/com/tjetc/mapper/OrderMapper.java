package com.tjetc.mapper;

import com.tjetc.domain.Order;

import java.util.List;
import java.util.Map;

public interface OrderMapper {
    int addSettleAccounts(Order order);

    int updateOrdersAddress(Order order);

    Order selectByMyCartId(Map<String,Object> map);

    List<Order> selectByUserId(Integer userId);

    int updateOrderByState(Order order);

    List<Order> selectUserOrders(Map map);

    List<Order> selectOrderStatus(Map<String,Object> map);

    List<Order> selectState(Map<String,Object> map);

    int deleteById(Integer order_id);

    Order selectByIdAndOrder(Integer id);

    int updateByIdOrderStatus(Order order);

    void updateOrderEvaluate(Order order);

    List<Order> selectByOrderEvaluate(Map<String,Object> map);

    Order selectOrderApplyForRefundById(Integer id);

    int updateOrderApplySubmit(Order order);

    List<Order> selectOrderByReasonsRefund();

    int updateByIdAndOrder(Order order);

    List<Order> selectOrderByNameLayui(Map<String, Object> map);

    List<Order> selectUserOrderByReason(Map<String, Object> map);

    List<Order> selectOrderByExpeditingDelivery();

    int updateOrderByIdAndStatedAndStatus(Order order);

    int updateOrdersExpeditingDelivery(Order order);

    int deleOrderByNoPayment(Map<String, Object> map);
}
