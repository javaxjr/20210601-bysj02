package com.tjetc.mapper;

import com.tjetc.domain.MyCat;

import java.util.List;
import java.util.Map;

public interface MyCatMapper {
    List<MyCat> selectByMyCat(int user_id);

    int addByMyCat(Map<String,Object> map);

    int delById(Integer id);

    MyCat selectUIdByPId(Map<String, Object> map);

    int delByUIdAndPId(MyCat myCat);

    MyCat selectByMyCartId(Integer myCart_id);

    MyCat selectByPidAndUid(MyCat myCat);

    MyCat findByMyCartId(Integer id);

    int updateMyCart(MyCat myCat);
}
