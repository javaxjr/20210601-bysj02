package com.tjetc.domain;

/*
* 收藏表 用户收藏自己喜欢的物品
* */
public class CollectionNow {
    private Integer id;
    private Integer user_id;
    private Integer product_id;

    private User user;
    private Product product;

    public CollectionNow() {
    }

    public CollectionNow(Integer id, Integer user_id, Integer product_id, User user, Product product) {
        this.id = id;
        this.user_id = user_id;
        this.product_id = product_id;
        this.user = user;
        this.product = product;
    }

    @Override
    public String toString() {
        return "CollectionNow{" +
                "id=" + id +
                ", user_id=" + user_id +
                ", product_id=" + product_id +
                ", user=" + user +
                ", product=" + product +
                '}';
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }
}
