package com.tjetc.mapper;

import com.tjetc.domain.AcknowledgementOrder;

import java.util.List;

public interface AcknowledgementOrderMapper {
    int addSubmit(AcknowledgementOrder acknowledgementOrder);

    int updateOrderStatus(String order_status);

    List<AcknowledgementOrder> selectByOrderStatus(String order_status);

    int deleteById(Integer id);
}
