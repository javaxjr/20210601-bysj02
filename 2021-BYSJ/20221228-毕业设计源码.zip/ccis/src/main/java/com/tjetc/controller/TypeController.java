package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Type;
import com.tjetc.service.TypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Controller
@RequestMapping("/type")
public class TypeController {

    @Autowired
    private TypeService typeService;
    @GetMapping("/add")
    public String add(){
        return "productType/add_product_type";
    }
    @PostMapping("/add")
    @ResponseBody
    public boolean add(Type type){

       /* String id= UUID.randomUUID().toString().trim().substring(0,4);
        type.setId("T"+id);*/
        return typeService.add(type);
    }

    @RequestMapping("/listByName")
    public String listByName(@RequestParam(defaultValue = "")String product_type,
                                     @RequestParam(defaultValue = "1")Integer pageNum,
                                     @RequestParam(defaultValue = "5")Integer pageSize, Model model){

        Map<String,Object> map= new HashMap<String,Object>();
        map.put("product_type",product_type);
        PageInfo<Type> pageInfo = typeService.listByName(map, pageNum, pageSize);

        model.addAttribute("page",pageInfo);
        model.addAttribute("product_type",product_type);
        return "productType/list_product_type";
    }

    @RequestMapping("/findById")
    @ResponseBody
    public Type findById(Integer id){

        //System.out.println("id = " + id);
        Type type = typeService.findById(id);
        return type;
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(Type type){
        return typeService.updateById(type);
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean delById(Integer id){
        return typeService.delById(id);
    }

}
