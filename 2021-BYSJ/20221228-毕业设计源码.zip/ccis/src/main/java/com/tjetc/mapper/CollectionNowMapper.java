package com.tjetc.mapper;

import com.tjetc.domain.CollectionNow;

import java.util.List;

public interface CollectionNowMapper {
    int addCollectionNow(CollectionNow collectionNow);

    List<CollectionNow> selectByUserCollectionNow(Integer user_id);

    CollectionNow selectByPidAndUid(CollectionNow collectionNow);

    void deleteById(Integer id);
}
