package com.tjetc.service.impl;

import com.tjetc.domain.Evaluation;
import com.tjetc.mapper.EvaluationMapper;
import com.tjetc.service.EvaluationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EvaluationServiceImpl implements EvaluationService {

    @Autowired
    private EvaluationMapper evaluationMapper;

    public int addEvaluation(Evaluation evaluation) {
        return evaluationMapper.addEvaluation(evaluation);
    }

    public List<Evaluation> selectByIdAndOrderDetail(Integer product_id) {
        return evaluationMapper.selectByIdAndOrderDetail(product_id);
    }
}
