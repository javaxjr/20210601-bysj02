package com.tjetc.service;

import com.github.pagehelper.PageInfo;

import java.util.Map;

/*
* 公共接口
* */
public interface CommonService {

    public <T> int addSave(Map<String,Object> map,T t);

    public <T> PageInfo<T> selectByName(Map<String,Object> map, Integer pageNum, Integer pageSize, T t);

    public <T> int updateCommon(Map<String,Object> map,T t);

    public <T> int deleteCommonById(Object object,T t);
}
