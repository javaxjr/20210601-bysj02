package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Product;
import com.tjetc.domain.Type;

import java.util.List;
import java.util.Map;

public interface TypeService {
    boolean add(Type type);

    PageInfo<Type> listByName(Map<String, Object> map, Integer pageNum, Integer pageSize);

    Type findById(Integer id);

    boolean updateById(Type type);

    boolean delById(Integer id);

    List<Type> selectByProductType();

    List<Type> selectProductByType(String type);
}
