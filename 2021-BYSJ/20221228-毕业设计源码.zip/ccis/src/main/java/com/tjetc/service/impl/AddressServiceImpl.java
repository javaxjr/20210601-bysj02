package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Address;
import com.tjetc.mapper.AddressMapper;
import com.tjetc.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AddressServiceImpl implements AddressService {

    @Autowired
   private  AddressMapper  addressMapper;
    public boolean addAddress(Address address) {
        return (addressMapper.addAddress(address))>0?true:false;
    }

    public PageInfo<Address> listByAndName(Map<String, Object> map, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<Address> list=addressMapper.listByAndName(map);
        PageInfo<Address> pageInfo = new PageInfo<Address>(list);
        return pageInfo;
    }

    public Address findById(Integer id) {
        return addressMapper.findById(id);
    }

    public boolean updateById(Address address) {
        return (addressMapper.updateById(address))>0?true:false;
    }

    public boolean delById(Integer id) {
        return (addressMapper.delById(id))>0?true:false;
    }

    public List<Address> selectAddress(Integer user_id) {
        return addressMapper.selectAddress(user_id);
    }

    public void updateByDefaultAddress(Map<String,Object> map) {
        addressMapper.updateByDefaultAddress(map);
    }

    public Address selectAddressDefaultByUid(int uid) {
        return addressMapper.selectAddressDefaultByUid(uid);
    }
}
