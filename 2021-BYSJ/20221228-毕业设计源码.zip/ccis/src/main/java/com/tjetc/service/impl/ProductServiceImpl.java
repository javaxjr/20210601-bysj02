package com.tjetc.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Product;
import com.tjetc.mapper.ProductMapper;
import com.tjetc.service.ProductService;
import com.tjetc.util.ExcelUtils;
import com.tjetc.util.excel.DownloadExcel;
import com.tjetc.util.excel.UploadExcelAndList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductMapper productMapper;

    public int add(Product product) {
        return productMapper.add(product);
    }

    public PageInfo<Product> listByName(String name, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<Product> list=productMapper.listByName(name);
        PageInfo<Product> pageInfo = new PageInfo<Product>(list);
        return pageInfo;
    }

    public Product findById(Integer id) {
        return productMapper.findById(id);
    }

    public int updateById(Product product) {
        return productMapper.updateById(product);
    }

    public int deleteById(Integer id) {
        return productMapper.deleteById(id);
    }

    public List<Product> selectProduct() {
        return productMapper.selectProduct();
    }

    public PageInfo<Product> selectByProduct(Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        PageInfo<Product> pageInfo = new PageInfo<Product>(productMapper.selectProduct());
        return pageInfo;
    }

    public Product selectByIdAndOrderDetail(Integer product_id) {
        return productMapper.selectByIdAndOrderDetail(product_id);
    }

    public PageInfo<Product> selectSearchByName(String type, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<Product> productList = productMapper.selectSearchByType(type);
        PageInfo<Product> pageInfo = new PageInfo<Product>(productList);
        return pageInfo;
    }

    public Integer addProductUploadExcel(MultipartFile file) {

        List productList = UploadExcelAndList.addUploadExcel(file);
        if (productList!=null && productList.size()!=0){
            for (Object object : productList) {
                Product product = (Product) object;
                productMapper.add(product);
            }
            return 1;
        }else {
            return 0;
        }


    }
    //下载
    public void productExcel(List<Product> productList, String url) {
        DownloadExcel.productDownloadExcel(productList,url);
    }

    public <T> List<T> saveExcelFile(MultipartFile mulFile, T t) {
        if (!mulFile.isEmpty()) {
            try {
                String filename = mulFile.getOriginalFilename();
                String suffix = filename.substring(filename.lastIndexOf("."));// 后缀名
                String uuid = UUID.randomUUID().toString();
                String uuidName = uuid + suffix;
                String path = "c:/upload/"+uuidName;
                //String saveType = getSaveFileType(t);
                //saveFileInfo(filename,uuidName,path,saveType);//文件信息插入到数据库
                File file = new File(path);
                file.mkdirs();
                File dest = new File(path);

                /*取出Excel表中的每一个单元格的值，存放在list集合中*/
                InputStream in = mulFile.getInputStream();
                //lastIndexOf() 方法可返回一个指定的字符串值最后出现的位置,如果指定第二个参数 start,则在一个字符串中的指定位置从后向前搜索。”
                //String type = t.toString().substring(t.toString().lastIndexOf(".")+1, t.toString().lastIndexOf("#"));
                List<List<Object>> bankListByExcel = ExcelUtils.getBankListByExcel(in, filename,"4545");
                /*保存上传的Excel文件到本地目录*/
                mulFile.transferTo(dest);
                String errors = ExcelUtils.getErrors();
                List<T> list = null;
                if(errors.isEmpty()){
                    list = ExcelUtils.listDisToObj(bankListByExcel, t, filename);
                }
                return list;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public List<String> selectProvince() {
        return productMapper.selectProvince();
    }


   /* public List<Product> selectProductByType(String type) {
        return productMapper.selectSearchByType(type);
    }*/
}
/*
* <div class="foot1">
             <ul>
                 <li>© 2010-2020 1688.com 版权所有</li>
                 <li>关于阿里巴巴</li>
                 <li>联系我们</li>
                 <li>知识产权</li>
                 <li>著作权与商标声明</li>
                 <li>法律声明</li>
                 <li>服务条款</li>
                 <li>隐私政策</li>
                 <li>网站导航</li>
             </ul>
         </div>
         <div class="foot2">
             <ul>
                 <li>阿里巴巴集团</li>
                 <li>阿里巴巴国际站</li>
                 <li>1688</li>
                 <li>全球速卖通</li>
                 <li>淘宝网</li>
                 <li>天猫</li>
                 <li>聚划算</li>
                 <li>一淘</li>
                 <li>飞猪</li>
                 <li>阿里妈妈</li>
                 <li>虾米</li>
                 <li>阿里云计算</li>
                 <li>YunOS</li>
                 <li>阿里通信</li>
                 <li>万网</li>
                 <li>UC</li>
                 <li>支付宝</li>
                 <li>钉钉</li>
                 <li>阿里健康</li>
                 <li>一达通</li>
                 <li>Lazada</li>
             </ul>
         </div>
* */