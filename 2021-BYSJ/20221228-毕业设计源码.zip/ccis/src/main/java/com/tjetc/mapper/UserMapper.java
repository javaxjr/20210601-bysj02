package com.tjetc.mapper;

import com.tjetc.domain.User;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface UserMapper {

    int addUser(User user);

    List<User> listByName(String name);

    User findById(Integer id);

    boolean delById(Integer id);

    User selectUsernameAndPassword(Map<String,Object> map);

    int updateByUserMoney(User user);

    int updateByUserPaymentPassword(User user);

    int updateById(User user);

    int updateUserAndPassword(User user);

    int updateUserGrade(User user);

    int updateUserRechargeAndMoney(User user);

    User selectByUserObject(Map<String,Object> map);

    User findByUsername(String username);

}
