package com.tjetc.domain;

/*
* 商家表，，商品由此 由商家出品，然后用户购买的时候，支付金额到此商家
* */
public class Business {
    private Integer id;
    private String business_name;//商家名称
    private double balance;//商家余额

    public Business() {
    }

    public Business(Integer id, String business_name, double balance) {
        this.id = id;
        this.business_name = business_name;
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Business{" +
                "id=" + id +
                ", business_name='" + business_name + '\'' +
                ", balance=" + balance +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getBusiness_name() {
        return business_name;
    }

    public void setBusiness_name(String business_name) {
        this.business_name = business_name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
