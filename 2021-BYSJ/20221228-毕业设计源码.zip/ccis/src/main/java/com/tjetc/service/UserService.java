package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.User;

import java.util.Map;

public interface UserService {
    int addUser(User user);

    PageInfo<User> listByName(String name, Integer pageNum, Integer pageSize);

    User findById(Integer id);

    boolean delById(Integer id);

    User selectUsernameAndPassword(String username, String password);

    int updateByUserMoney(User user);

    int updateByUserPaymentPassword(User user);

    int updateById(User user);

    int updateUserAndPassword(User user);

    int updateUserGrade(User user);

    int updateUserRechargeAndMoney(User user);

    User selectByUserObject(Map<String,Object> map);

    User findByUsername(String value);

    int updateSetUpUserPayment(User user);
}
