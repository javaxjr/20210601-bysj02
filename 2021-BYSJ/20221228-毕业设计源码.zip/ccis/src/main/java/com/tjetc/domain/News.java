package com.tjetc.domain;

/**
 * 新闻表
 */
public class News {

    private Integer id;//编号
    private String title;//标题
    private String photopath;//照片
    private String content;//内容
}
