package com.tjetc.mapper;

import com.tjetc.domain.Address;

import java.util.List;
import java.util.Map;

public interface AddressMapper {
    int addAddress(Address address);

    List<Address> listByAndName(Map<String, Object> map);

    Address findById(Integer id);

    int updateById(Address address);

    int delById(Integer id);

    List<Address> selectAddress(Integer user_id);

    void updateByDefaultAddress(Map<String,Object> map);

    Address selectAddressDefaultByUid(int uid);
}
