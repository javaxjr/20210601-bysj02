package com.tjetc.util.excel;

import com.tjetc.domain.Product;
import org.apache.poi.hssf.usermodel.*;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.URLEncoder;
import java.util.List;


/*
* 实现信息下载，对信息进行处理的类
* */

public class DownloadExcel {

    //表格布局  //下载
    public static boolean  productDownloadExcel(List list, String url){
        //1.创建一个webbook, 对应一个Excel文件
        HSSFWorkbook wb = new HSSFWorkbook();
        // 第二步，在webbook中添加一个sheet,对应Excel文件中的sheet
        HSSFSheet sheet = wb.createSheet();
        //第三部，在sheet中添加表头0行，注意老版本POI对Excel的行列数有限制short
        HSSFRow row = sheet.createRow((int)0);
        //第四步：创建单元格，并设置值表头，设置表头居中
        HSSFCellStyle style = wb.createCellStyle();
        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);//创建一个居中格式

        HSSFCell cell = row.createCell((short) 0);
        cell.setCellValue("编号");
        cell.setCellStyle(style);

        cell = row.createCell((short)1);
        cell.setCellValue("商品名称");
        cell.setCellStyle(style);

        cell = row.createCell((short)2);
        cell.setCellValue("单价");
        cell.setCellStyle(style);

        cell = row.createCell((short)3);
        cell.setCellValue("库存量");
        cell.setCellStyle(style);

        cell = row.createCell((short)4);
        cell.setCellValue("商品图片");
        cell.setCellStyle(style);

        cell = row.createCell((short)5);
        cell.setCellValue("商品简介");
        cell.setCellStyle(style);

        cell = row.createCell((short)6);
        cell.setCellValue("商品详情");
        cell.setCellStyle(style);

        cell = row.createCell((short)7);
        cell.setCellValue("商品类型");
        cell.setCellStyle(style);

        cell = row.createCell((short)8);
        cell.setCellValue("商品所属公司");
        cell.setCellStyle(style);

        cell = row.createCell((short)9);
        cell.setCellValue("30天成交量");
        cell.setCellStyle(style);

        //第五步、写入实体数据，数据时从数据库得到
        for (int i = 0; i < list.size(); i++) {
            row = sheet.createRow((int)i+1);
            Product product = (Product) list.get(i);

            //第四步、创建单元格、设置值
            row.createCell((short)0).setCellValue(product.getId());
            row.createCell((short)1).setCellValue(product.getName());
            row.createCell((short)2).setCellValue(product.getPrice());
            row.createCell((short)3).setCellValue(product.getCount());
            row.createCell((short)4).setCellValue(product.getPhotopath());
            row.createCell((short)5).setCellValue(product.getBriefly());
            row.createCell((short)6).setCellValue(product.getDetails());
            row.createCell((short)7).setCellValue(product.getType());
            row.createCell((short)8).setCellValue(product.getCompanies());
            row.createCell((short)9).setCellValue(product.getTurnover());
        }

        //第六步、将文件存到指定位置C:\Users\17814\Desktop
        try {
            FileOutputStream fps = new FileOutputStream("c:/Users/17814/Desktop/"+url+".xls");
            wb.write(fps);
            fps.close();
            return true;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    //下载模板
    public static  void  download(HttpServletRequest request, HttpServletResponse response, String filename) throws IOException {
        //download.download为需要下载的文件
        //String filename = "downloadExcel.download";   //filename由前端页面传送   有多个文件需要下载
        //获取文件的绝对路径名称，apk为根目录下的一个文件夹，这个只能获取根目录文件夹的绝对路径
        String path = request.getSession().getServletContext().getRealPath("download")+"\\"+filename;
        System.out.println("path = " + path);
        //得到要下载的文件
        File file = new File(path);
        if (!file.exists()){
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().println("<html><body><script type='text/javascript'>alert('您要下载的资源已被删除！！');</script></body></html>");
            response.getWriter().close();
            System.out.println("您要下载的资源已被删除");
            return;
        }
        //转码  免得文件名称中文乱码
        filename = URLEncoder.encode(filename,"UTF-8");
        //设置文件下载头
        response.addHeader("Content-Disposition","attachment;filename="+filename);
        //设置文件contentType类型 ，这样设置，会自动判断下载文件类型
        response.setContentType("multipart/form-data");
        //读取要下载的文件输入流，保存到文件输入流
        FileInputStream in = new FileInputStream(path);
        //创建输出流
        ServletOutputStream out = response.getOutputStream();
        //创建缓冲区
        byte buffer[] = new byte[1024];//缓冲区的大小设置是个迷，一般都是1024
        int len= 0;
        //循环将输入流中的内容读取到缓冲区当中
        while ((len = in.read(buffer))>0){
            out.write(buffer,0,len);
        }
        //关闭文件输入流
        in.close();
        //关闭文件输出流
        out.close();
    }

}
