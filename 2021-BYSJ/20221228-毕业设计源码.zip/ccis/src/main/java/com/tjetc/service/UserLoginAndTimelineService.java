package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.UserLoginAndTimeline;

import java.util.List;

public interface UserLoginAndTimelineService {
    void addUserTimeline(UserLoginAndTimeline usertimeline);

    PageInfo<UserLoginAndTimeline>  selectUserLoginAndTimelineByUid(Integer userId);
}
