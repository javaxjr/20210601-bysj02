package com.tjetc.controller;

import com.tjetc.domain.*;
import com.tjetc.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/acknowledgementOrder")
public class AcknowledgementOrderController {


    //定义一个静态的时间变量  限时为30分钟
    // 每次用户提交订单后，需要在30分钟内支付，则该订单自动删除
    public static int time = 30 * 60;
    @Autowired
    private AcknowledgementOrderService acknowledgementOrderService;
    @Autowired
    private ProvisionalService provisionalService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private UserService userService;
    @Autowired
    private ProductService productService;
    @Autowired
    private BusinessService businessService;
    @Autowired
    private MyCatService myCatService;

    @RequestMapping("/add")
    @ResponseBody
    public boolean add(AcknowledgementOrder acknowledgementOrder) {
        List<Provisional> list = provisionalService.selectByProvisional2();

        if (list.size() > 0) {
            for (Provisional provisional : list) {

                Map map = new HashMap<String, Object>();
                map.put("myCart_id", provisional.getMyCart_id());
                map.put("uid", provisional.getUser_id());

                Order order = orderService.selectByMyCartId(map);
                Integer orderId = order.getId();
                acknowledgementOrder.setOrder_id(orderId);
                acknowledgementOrder.setOrder_status("订单未提交");
                int i = acknowledgementOrderService.addSubmit(acknowledgementOrder);
            }
            return true;
        }

        return false;
    }

    @RequestMapping("/updateOrderStatus")
    @ResponseBody
    public boolean updateOrderStatus(Double subtotal, HttpServletRequest request) {
        HttpSession session = request.getSession();
        session.setAttribute("subtotal", subtotal);
        //System.out.println("subtotal = " + subtotal);
        String order_status = "订单已提交";
        int i = acknowledgementOrderService.updateOrderStatus(order_status);
        User user = (User) session.getAttribute("user");
        List<Provisional> provisionalList = provisionalService.selectByProvisional(user.getId());

        for (Provisional provisional : provisionalList) {
            int i1 = myCatService.delById(provisional.getMyCart_id());
        }


        return i > 0 ? true : false;
    }

    //用于扣除用户金额用的，进行订单结算   立即支付
    @RequestMapping("/payImmediately")
    @ResponseBody
    public boolean payImmediately(Double subtotal, String payment, HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (payment.equals(user.getPayment())) {
            //System.out.println("user = " + user);
            //获取用户的 账户余额信息
            Double user_money = user.getUser_money();
            user_money = user_money - subtotal;
            user.setUser_money(user_money);
            int i = userService.updateByUserMoney(user);
            //System.out.println("user_money = " + user_money);

            //获取要支付的商家的信息，，商品所对应的商家  从临时表Provisional中获取
            List<Provisional> list = provisionalService.selectByUserId(user.getId());
            for (Provisional provisional : list) {
                Integer product_id = provisional.getProduct_id();
                Product product = productService.findById(product_id);
                String companies = product.getCompanies();
                //商家
                Business business = businessService.selectByCompanies(companies);
                double balance = business.getBalance();
                Double product_price = product.getPrice();

                if ("钻石".equals(user.getGrade())) {
                    balance = balance + (product_price * provisional.getCount() * 0.9);
                } else if ("星耀".equals(user.getGrade())) {
                    balance = balance + (product_price * provisional.getCount() * 0.8);
                } else if ("王者".equals(user.getGrade())) {
                    balance = balance + (product_price * provisional.getCount() * 0.7);
                }
                business.setBalance(balance);
                int i2 = businessService.updateByBalance(business);


            }

            //支付完成之后修改订单中的状态
            Integer userId = user.getId();
            List<Provisional> provisionalList = provisionalService.selectByProvisional(userId);
            for (Provisional provisional : provisionalList) {

                //根据购物车编号的唯一性   支付一条已经提交的订单
                Map map = new HashMap<String, Object>();
                map.put("myCart_id", provisional.getMyCart_id());
                map.put("uid", provisional.getUser_id());
                Order order = orderService.selectByMyCartId(map);
                if ("未支付".equals(order.getState())) {
                    order.setState("已支付");
                    order.setPaymentDate(new Date());
                    int i3 = orderService.updateOrderByState(order);
                }

                /*修改库存量  以及修改成交量*/
                Integer productId = provisional.getProduct_id();
                Product product = productService.findById(productId);
                String productTurnover = product.getTurnover();
                int turnover = Integer.parseInt(productTurnover);

                /*成交量*/
                turnover = turnover + provisional.getCount();

                Integer count = product.getCount();
                Integer pCount = order.getpCount();
                count = count - pCount;
                product.setCount(count);
                product.setTurnover(turnover + "");
                productService.updateById(product);


            /*List<Order> orderList = orderService.selectByUserId(provisional.getMyCart_id());
            for (Order order : orderList) {
                if ("未支付".equals(order.getState())){
                    order.setState("已支付");
                    order.setPaymentDate(new Date());
                    int i3 = orderService.updateOrderByState(order);
                }

            }*/
            }

            //重新获取用户的信息
            user = userService.findById(user.getId());
            session.setAttribute("user", user);
            return i > 0 ? true : false;
        } else {
            return false;
        }

    }

    /*从个人中心中支付未支付的订单*/
    @RequestMapping("/paymentOrder2")
    @ResponseBody
    public boolean paymentOrder2(Integer id, String payment, HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (payment.equals(user.getPayment())) {
            Order order = orderService.selectByIdAndOrder(id);

            if (user.getUser_money() >= order.getSumPCount()) {
                Double userMoney = user.getUser_money();
                userMoney = userMoney - order.getSumPCount();
                Integer uid = order.getUid();
                Product product = productService.findById(uid);
                Business business = businessService.selectByCompanies(product.getCompanies());
                double balance = business.getBalance();
                balance = balance + order.getSumPCount();
                order.setState("已支付");
                int i = orderService.updateOrderByState(order);

                /*支付之后减去商品在数据库中的  库存量*/
                int pcount = order.getpCount();
                Integer pid = order.getPid();
                Product product1 = productService.findById(pid);
                Integer product1Count = product1.getCount();
                /*获取成交量*/
                String turnover = product1.getTurnover();
                int turnover2 = Integer.parseInt(turnover);
                product1Count = product1Count - pcount;
                turnover2 = turnover2 + order.getpCount();
                product1.setCount(product1Count);
                product1.setTurnover(turnover2 + "");
                productService.updateById(product1);

                //重新获取用户的信息
                user = userService.findById(user.getId());
                session.setAttribute("user", user);
                return true;
            } else {
                return false;
            }

        } else {
            return false;
        }
    }

    //设置当前登录用户的支付密码
    @RequestMapping("/setPaymentPassword")
    @ResponseBody
    public boolean setPaymentPassword(String payment, HttpServletRequest request) {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        user.setPayment(payment);
        //修改用户的支付密码
        int i = userService.updateByUserPaymentPassword(user);
        User user1 = userService.findById(user.getId());
        session.setAttribute("user", user1);
        return i > 0 ? true : false;
    }

}
