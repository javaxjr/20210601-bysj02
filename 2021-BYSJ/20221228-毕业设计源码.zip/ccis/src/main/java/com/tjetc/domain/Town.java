package com.tjetc.domain;

/*城镇区域表*/
public class Town extends AddressRegion{
    /*private int id;
    private String provinces_cities;//省市*/
    private String city_county;//市县
    private String tTown;//城镇，或者是所在的区

    public Town() {
    }

    @Override
    public String toString() {
        return "Town{" +
                "city_county='" + city_county + '\'' +
                ", tTown='" + tTown + '\'' +
                '}';
    }

    public String getCity_county() {
        return city_county;
    }

    public void setCity_county(String city_county) {
        this.city_county = city_county;
    }

    public String gettTown() {
        return tTown;
    }

    public void settTown(String tTown) {
        this.tTown = tTown;
    }
}
