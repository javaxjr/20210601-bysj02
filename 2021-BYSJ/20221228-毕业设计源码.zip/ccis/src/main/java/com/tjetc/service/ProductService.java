package com.tjetc.service;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Product;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface ProductService {
    int add(Product product);

    PageInfo<Product> listByName(String name, Integer pageNum, Integer pageSize);

    Product findById(Integer id);

    int updateById(Product product);

    int deleteById(Integer id);

    List<Product> selectProduct();

    PageInfo<Product> selectByProduct(Integer pageNum, Integer pageSize);

    Product selectByIdAndOrderDetail(Integer product_id);

    PageInfo<Product> selectSearchByName(String type, Integer pageNum, Integer pageSize);

    Integer addProductUploadExcel(MultipartFile file);

    void productExcel(List<Product> productList, String url);

    /*List<Product> selectProductByType(String type);*/

    public <T> List<T> saveExcelFile(MultipartFile mulFile, T t);

    List<String> selectProvince();
}
