package com.tjetc.mapper;

import com.tjetc.domain.Business;

import java.util.List;

public interface BusinessMapper {
    int add(Business business);

    Business selectByCompanies(String companies);

    int updateByBalance(Business business);

    boolean deleteById(Integer id);

    int updateById(Business business);

    Business findById(Integer id);

    List<Business> selectByBusinessName(String business_name);
}
