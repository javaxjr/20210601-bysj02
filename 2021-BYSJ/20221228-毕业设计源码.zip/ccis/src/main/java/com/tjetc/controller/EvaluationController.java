package com.tjetc.controller;

import com.tjetc.domain.Evaluation;
import com.tjetc.domain.Order;
import com.tjetc.domain.User;
import com.tjetc.service.EvaluationService;
import com.tjetc.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.UUID;

@Controller
@RequestMapping("/evaluation")
public class EvaluationController {

    @Autowired
    private EvaluationService evaluationService;
    @Autowired
    private OrderService orderService;

    @RequestMapping("/addEvaluation")
    @ResponseBody
    public boolean addEvaluation(Evaluation evaluation, MultipartFile photo, HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Integer userId = user.getId();
        evaluation.setUser_id(userId);

        if (photo!=null && photo.getSize()>0) {
            String realPath = request.getServletContext().getRealPath("/upload/");
            File file = new File(realPath);
            if (!file.exists()) {
                file.mkdir();
            }
            String filename = photo.getOriginalFilename();
            String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filename;
            File file2 = new File(file, uuidFileName);
            System.out.println("uuidFileName = " + uuidFileName);
            evaluation.setPhotopath("upload/"+uuidFileName);
            try {
                photo.transferTo(file2);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        evaluation.seteDate(new Date());
        int i = evaluationService.addEvaluation(evaluation);
        System.out.println("evaluation = " + evaluation);

        Order order = orderService.selectByIdAndOrder(evaluation.getOrder_id());
        order.setOrder_evaluate("已评价");
        orderService.updateOrderEvaluate(order);

        return i>0?true:false;
    }

}
