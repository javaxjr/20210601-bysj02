package com.tjetc.domain;

/*
* 确认订单，当提交订单时，相关的订单的数据就会存到这里，存的是订单的编号
* */
public class AcknowledgementOrder {

    private Integer id;
    private Integer order_id;//订单编号
    private String order_status;//来标志订单是否已提交


    public AcknowledgementOrder() {
    }

    public AcknowledgementOrder(Integer id, Integer order_id, String order_status) {
        this.id = id;
        this.order_id = order_id;
        this.order_status = order_status;
    }

    @Override
    public String toString() {
        return "AcknowledgementOrder{" +
                "id=" + id +
                ", order_id=" + order_id +
                ", order_status='" + order_status + '\'' +
                '}';
    }

    public String getOrder_status() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status = order_status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrder_id() {
        return order_id;
    }

    public void setOrder_id(Integer order_id) {
        this.order_id = order_id;
    }
}
