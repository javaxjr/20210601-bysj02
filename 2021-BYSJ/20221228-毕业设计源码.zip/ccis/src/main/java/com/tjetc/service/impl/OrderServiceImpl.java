package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Order;
import com.tjetc.mapper.OrderMapper;
import com.tjetc.service.OrderService;
import org.aspectj.weaver.ast.Or;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderMapper orderMapper;

    public int addSettleAccounts(Order order) {
        return orderMapper.addSettleAccounts(order);
    }

    public int updateOrdersAddress(Order order) {
        return orderMapper.updateOrdersAddress(order);
    }

    public Order selectByMyCartId(Map<String,Object> map) {
        return orderMapper.selectByMyCartId(map);
    }

    public List<Order> selectByUserId(Integer userId) {
        return orderMapper.selectByUserId(userId);
    }

    public int updateOrderByState(Order order) {
        return orderMapper.updateOrderByState(order);
    }

    public PageInfo<Order> selectUserOrders(Map map, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<Order> orderList = orderMapper.selectUserOrders(map);
        PageInfo<Order> pageInfo = new PageInfo<Order>(orderList);
        return pageInfo;
    }

    public List<Order> selectOrderStatus(Map<String,Object> map) {
        return orderMapper.selectOrderStatus(map);
    }

    public List<Order> selectState(Map<String,Object> map) {
        return orderMapper.selectState(map);
    }

    public int deleteById(Integer order_id) {
        return orderMapper.deleteById(order_id);
    }

    public Order selectByIdAndOrder(Integer id) {
        return orderMapper.selectByIdAndOrder(id);
    }

    public int updateByIdOrderStatus(Order order) {
        return orderMapper.updateByIdOrderStatus(order);
    }

    public boolean deleteOrderById(Integer id) {
       int i = orderMapper.deleteById(id);
        return i>0?true:false;
    }

    public void updateOrderEvaluate(Order order) {
        orderMapper.updateOrderEvaluate(order);
    }

    public List<Order> selectByOrderEvaluate(Map<String,Object> map) {
        return orderMapper.selectByOrderEvaluate(map);
    }

    public Order selectOrderApplyForRefundById(Integer id) {
        return orderMapper.selectOrderApplyForRefundById(id);
    }

    public int updateOrderApplySubmit(Order order) {
        return orderMapper.updateOrderApplySubmit(order);
    }

    public List<Order> selectOrderByReasonsRefund() {
        return orderMapper.selectOrderByReasonsRefund();
    }

    public PageInfo<Order> listByNameAndOrdersReasonsRefund(Map<String, Object> map, Integer pageNum, Integer pageSize) {

        List<Order> orderList = orderMapper.selectOrderByReasonsRefund();
        PageHelper.startPage(pageNum,pageSize);
        PageInfo<Order> pageInfo = new PageInfo<Order>(orderList);

        return pageInfo;
    }

    public Order findOrderById(Integer id) {
        return orderMapper.selectOrderApplyForRefundById(id);
    }

    public int updateByIdAndOrder(Order order) {
        return orderMapper.updateByIdAndOrder(order);
    }

    public PageInfo<Order> selectOrderByNameLayui(Map<String, Object> map, int pageNum, int pageSize) {

        List<Order> list = orderMapper.selectOrderByNameLayui(map);
        PageHelper.startPage(pageNum,pageSize);
        PageInfo<Order> pageInfo = new PageInfo<Order>(list);
        return pageInfo;
    }

    public PageInfo<Order> selectUserOrderByReason(Map<String, Object> map, int pageNum, int pageSize) {

        List<Order> list = orderMapper.selectUserOrderByReason(map);
        PageHelper.startPage(pageNum,pageSize);
        PageInfo<Order> pageInfo = new PageInfo<Order>(list);
        return pageInfo;
    }

    public List<Order> selectOrderByExpeditingDelivery() {
        return orderMapper.selectOrderByExpeditingDelivery();
    }

    public int updateOrderByIdAndStatedAndStatus(Order order) {
        return orderMapper.updateOrderByIdAndStatedAndStatus(order);
    }

    public int updateOrdersExpeditingDelivery(Order order) {
        return orderMapper.updateOrdersExpeditingDelivery(order);
    }

    @Override
    public int deleOrderByNoPayment(Map<String, Object> map) {
        return orderMapper.deleOrderByNoPayment(map);
    }


}
