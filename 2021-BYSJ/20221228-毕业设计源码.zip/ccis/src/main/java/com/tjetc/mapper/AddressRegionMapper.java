package com.tjetc.mapper;

import com.tjetc.domain.AddressRegion;

import java.util.List;
import java.util.Map;

public interface AddressRegionMapper {
    int add(AddressRegion addressRegion);

    List<AddressRegion> listByAndName(Map<String, Object> map);

    AddressRegion findById(Integer id);

    int updateById(AddressRegion addressRegion);

    int delById(Integer id);

    List<AddressRegion> selectByAddressRegion();
}
