package com.tjetc.service;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Admin;

import java.util.List;
import java.util.Map;

public interface AdminService {
    int add(Admin admin);

    Admin findById(Integer id);

    PageInfo<Admin> listByName(String name, Integer pageName, Integer pageSize);

    int updateById(Admin admin);

    boolean delById(Integer id);

    Admin selectByUsernameAndPassword(Map<String, Object> map);

    int updateAdminPasswordById(Admin admin);

    Admin selectUserNameByPhone(Map<String,Object> map);

    List<Map<String, String>> selectByMapProduct(JSONObject jsonObject);
}
