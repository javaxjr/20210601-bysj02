package com.tjetc.controller;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.*;
import com.tjetc.service.*;
import com.tjetc.util.WebMapPageResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @Autowired
    private ProvisionalService provisionalService;

    @Autowired
    private ProductService productService;

    @Autowired
    private MyCatService myCatService;

    @Autowired
    private TownService townService;

    @Autowired
    private AddressService addressService;

    @Autowired
    private AcknowledgementOrderService acknowledgementOrderService;

    @Autowired
    private OrderDetailService orderDetailService;

    @Autowired
    private BusinessService businessService;

    @Autowired
    private UserService userService;
    /*
     * 管理员后台查看所有用户所有订单的情况
     * */
    @RequestMapping("/selectUserOrder")
    public String selectUserOrder(@RequestParam(defaultValue = "0")Integer uid,
                                  @RequestParam(defaultValue = "0")Integer pid,
                                  @RequestParam(defaultValue = "")String state,
                                  @RequestParam(defaultValue = "")String order_status,
                                  @RequestParam(defaultValue = "")String user_name,
                                  @RequestParam(defaultValue = "")String user_phone,
                                  @RequestParam(defaultValue = "")String provinces_cities,
                                  @RequestParam(defaultValue = "")String city_county,
                                  @RequestParam(defaultValue = "")String tTown,
                                  @RequestParam(defaultValue = "")String detail,
                                  @RequestParam(defaultValue = "1")Integer pageNum,
                                  @RequestParam(defaultValue = "8")Integer pageSize,
                                  Model model){

        Map map = new HashMap<String,Object>();
        map.put("uid",uid);
        map.put("pid",pid);
        map.put("state",state);
        map.put("order_status",order_status);
        map.put("user_name",user_name);
        map.put("user_phone",user_phone);
        map.put("provinces_cities",provinces_cities);
        map.put("city_county",city_county);
        map.put("tTown",tTown);
        map.put("detail",detail);

        PageInfo<Order> orderPageInfo = orderService.selectUserOrders(map,pageNum,pageSize);

        //System.out.println("orderPageInfo = " + orderPageInfo);
        model.addAttribute("uid",uid);
        model.addAttribute("pid",pid);
        model.addAttribute("state",state);
        model.addAttribute("order_status",order_status);
        model.addAttribute("user_name",user_name);
        model.addAttribute("user_phone",user_phone);
        model.addAttribute("provinces_cities",provinces_cities);
        model.addAttribute("city_county",city_county);
        model.addAttribute("tTown",tTown);
        model.addAttribute("detail",detail);
        model.addAttribute("page",orderPageInfo);
        return "/admin/user_orders_list";
    }

    //查看退货订单信息
    /*@RequestMapping("/listByNameAndOrdersReasonsRefund")
    @ResponseBody
    public WebMapPageResult listByNameAndOrdersReasonsRefund(HttpServletRequest request){
        Integer pageNum = Integer.parseInt(request.getParameter("page"));
        Integer pageSize = Integer.parseInt(request.getParameter("limit"));

        Map<String, Object> map = new HashMap<String, Object>();
        PageInfo<Order> pageInfo = orderService.listByNameAndOrdersReasonsRefund(map,pageNum,pageSize);

        return WebMapPageResult.success().setData(pageInfo.getList()).setCount(pageInfo.getTotal());
    }*/

    /*
    * 查询临时表中是否有  已选中的商品（在购物车中勾选）
    * */
    @RequestMapping("/selectProvisional")
    @ResponseBody
    public boolean selectProvisional(){
        List<Provisional> provisionalList = provisionalService.selectByProvisional2();
        int size = provisionalList.size();
        return size>0?true:false;
    }

    //先判断订单中是否已经添加 收货信息
    @RequestMapping("/selectUserAndOrderByAddress")
    @ResponseBody
    public boolean selectUserAndOrderByAddress(HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        List<Order> orderList = orderService.selectByUserId(user.getId());
        for (Order order : orderList) {
            String provincesCities = order.getProvinces_cities();
            //System.out.println("provincesCities = " + provincesCities);
            if (provincesCities == null || provincesCities!=null && provincesCities.trim().length()==0){
                return false;
            }
        }
        return true;
    }

    /*
    * 将购物车中的商品添加到订单中
    * */
    @RequestMapping("/addSettleAccounts")
    @ResponseBody
    public boolean addSettleAccounts(Order order,HttpServletRequest request){
        if (order!=null){

            HttpSession session = request.getSession();
            Double subtotal = order.getSubtotal();
            session.setAttribute("subtotal",subtotal);

            List<Provisional> list=provisionalService.selectByProvisional(order.getUid());
            for (Provisional provisional : list) {

                if (provisional==null){
                    return false;
                }
                //获取购物车的id  以便使用购物车中的相关字段
                order.setMyCart_id(provisional.getMyCart_id());
                //从购物车中获得  商品的属性
                MyCat myCat2 = myCatService.selectByMyCatId(provisional.getMyCart_id());
                order.setSize(myCat2.getSize());
                order.setPatten(myCat2.getPatten());
                order.setBrand(myCat2.getBrand());
                //取当前时间 作为提交订单的时间
                order.setOrderDate(new Date());
                //获得临时表中 商品的id  并赋值给订单表
                order.setPid(provisional.getProduct_id());
                //设置订单中单件商品的数量
                order.setpCount(provisional.getCount());
                //单件商品数量的总价格  sumPCount=pCount*price
                Product product = productService.findById(provisional.getProduct_id());
                order.setSumPCount(provisional.getCount()*product.getPrice());
                //当前订单的状态
                order.setState("未支付");
                //给订单的发货情况赋值
                order.setOrder_status("未发货");
                order.setExpediting_delivery("00");
                System.out.println("order = " + order);
                orderService.addSettleAccounts(order);


                /*删除购物车中选中的商品  在临时表中删除  根据商品id和用户id删除*/
                Provisional provisional2 = new Provisional();
                provisional2.setProduct_id(provisional.getProduct_id());
                provisional2.setUser_id(provisional.getUser_id());
                //provisionalService.delByPIdAndUId(provisional2);

                /*删除购物车中选中的商品  在购物车中删除*/
                MyCat myCat = new MyCat();
                myCat.setUser_id(provisional.getUser_id());
                myCat.setProduct_id(provisional.getProduct_id());
                //int i=myCatService.delByUIdAndPId(myCat);


                /*同时将订单中的订单编号   存到判断是否已提交订单的表中*/
                AcknowledgementOrder acknowledgementOrder = new AcknowledgementOrder();
                Map<String,Object> map = new HashMap<String, Object>();
                map.put("myCart_id",provisional.getMyCart_id());
                map.put("uid",provisional.getUser_id());
                map.put("pid",provisional.getProduct_id());
                Order order1 = orderService.selectByMyCartId(map);
                Integer orderId = order1.getId();
                acknowledgementOrder.setOrder_id(orderId);
                acknowledgementOrder.setOrder_status("未提交");
                int i = acknowledgementOrderService.addSubmit(acknowledgementOrder);


            }
            return true;
        }else {
            return false;
        }

    }

    /*
    * 订单催发货
    * */
    @RequestMapping("/updateOrdersExpeditingDelivery")
    @ResponseBody
    public boolean updateOrdersExpeditingDelivery(Integer id){
        Order order = orderService.findOrderById(id);
        order.setExpediting_delivery("01");
        int i = orderService.updateOrdersExpeditingDelivery(order);
        return i>0?true:false;
    }

    /*
    * 根据订单页面提交的  新添收货地址的信息  修改订单中的收货地址
    * */
    @RequestMapping("/updateOrdersAddress")
    @ResponseBody
    public boolean updateOrdersAddress(Order order, HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        order.setUid(user.getId());
        System.out.println("order = " + order);

        Address address = new Address();
        address.setUser_id(user.getId());
        address.setUser_name(order.getUser_name());
        address.setUser_phone(order.getUser_phone());
        address.setProvinces_cities(order.getProvinces_cities());
        address.setCity_county(order.getCity_county());
        address.settTown(order.gettTown());
        address.setDetail(order.getDetail());

        String defaultAddress=order.getDefault_address();

        if ("true".equals(defaultAddress)){
            Map<String,Object> map = new HashMap<String, Object>();
            map.put("defaultAddress","0");
            map.put("uid",user.getId());
            addressService.updateByDefaultAddress(map);
            address.setDefault_address("1");
        }
        addressService.addAddress(address);


        List<Provisional> list=provisionalService.selectByProvisional(user.getId());
        if (order!=null && order.getProvinces_cities().trim().length()>0){
            for (Provisional provisional : list) {
                order.setPid(provisional.getProduct_id());
                order.setMyCart_id(provisional.getMyCart_id());
                orderService.updateOrdersAddress(order);
            }
            return true;
        }
        return false;
    }

    //根据临时表中的相关信息，，查询最近一次提交的订单表中的订单信息，并显示出来
    @RequestMapping("/selectByOrderAndUserSubmit")
    public String selectOrder(Model model,HttpServletRequest request){
        List<Order> listOrders = new ArrayList<Order>();

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        if (user!=null){
            Double subtotal = (Double) session.getAttribute("subtotal");
            String grade = user.getGrade();
            double discount=1.0;
            if ("钻石".equals(grade)){
                discount=0.9;
            }else if ("星耀".equals(grade)){
                discount=0.8;
            }else if ("王者".equals(grade)){
                discount=0.7;
            }
            List<Provisional> list = provisionalService.selectByProvisional(user.getId());
            int size = list.size();
            if (size>0) {
                for (Provisional provisional : list) {
                    Map map = new HashMap<String, Object>();
                    map.put("myCart_id", provisional.getMyCart_id());
                    map.put("uid", provisional.getUser_id());
                    Order order = orderService.selectByMyCartId(map);
                    listOrders.add(order);
                }
                model.addAttribute("list", listOrders);
                model.addAttribute("size", size);
                model.addAttribute("subtotal", subtotal);
                model.addAttribute("discount", discount);
                System.out.println("listOrders = " + listOrders);

                return "/user/orders_user";
            }else {
               return "redirect:/myCat/selectByMyCat";

            }
        }else {
            return "index";
        }
    }

    @RequestMapping("/deleteOrderByUser")
    @ResponseBody
    public boolean deleteOrderByUser(HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("uId",user.getId());
        map.put("state","未支付");
        int i = orderService.deleOrderByNoPayment(map);
        return i>0?true:false;
    }

    /*根据订单是否支付查询*/
    @RequestMapping("/selectState")
    @ResponseBody
    public List<Order> selectState(String state,HttpServletRequest request){

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        Map<String,Object> map = new HashMap<String, Object>();
        map.put("state",state);
        map.put("uid",user.getId());

        List<Order> orderList = orderService.selectState(map);
        return orderList;
    }

    /*根据是否发货查询*/
    @RequestMapping("/selectOrderStatus")
    @ResponseBody
    public List<Order> selectOrderStatus(String order_status,HttpServletRequest request){

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        Map<String,Object> map = new HashMap<String, Object>();
        map.put("order_status",order_status);
        map.put("uid",user.getId());

        List<Order> orderList = orderService.selectOrderStatus(map);
        return orderList;
    }

    /*查询收货地址信息*/
    @RequestMapping("/receivingAddress")
    @ResponseBody
    public List<Address> receivingAddress(HttpServletRequest request){

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        List<Address>  addressList = addressService.selectAddress(user.getId());
       return addressList;
    }

    //将选择好的地址 录入到已提交的订单中
    @RequestMapping("/findByIdAdAddress")
    @ResponseBody
    public Address findByIdAdAddress(Integer id,HttpServletRequest request){

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        Address address = addressService.findById(id);
        Order order = new Order();

        order.setUid(user.getId());
        order.setUser_name(address.getUser_name());
        order.setUser_phone(address.getUser_phone());
        order.setProvinces_cities(address.getProvinces_cities());
        order.setCity_county(address.getCity_county());
        order.settTown(address.gettTown());
        order.setDetail(address.getDetail());


        List<Provisional> list=provisionalService.selectByProvisional(user.getId());
        if (order!=null && order.getProvinces_cities().trim().length()>0){
            for (Provisional provisional : list) {
                order.setPid(provisional.getProduct_id());
                order.setMyCart_id(provisional.getMyCart_id());
                orderService.updateOrdersAddress(order);
            }
        }

        order=null;
        return address;
    }

    //使用layui实现
    @RequestMapping("/selectUserOrderByNameAndLayui")
    @ResponseBody
    public WebMapPageResult selectUserOrderByNameAndLayui(@RequestParam(defaultValue = "0")Integer uid,
                                                          @RequestParam(defaultValue = "0")Integer pid,
                                                          @RequestParam(defaultValue = "")String state,
                                                          @RequestParam(defaultValue = "")String order_status,
                                                          @RequestParam(defaultValue = "")String user_name,
                                                          @RequestParam(defaultValue = "")String user_phone,
                                                          @RequestParam(defaultValue = "")String provinces_cities,
                                                          @RequestParam(defaultValue = "")String city_county,
                                                          @RequestParam(defaultValue = "")String tTown,
                                                          @RequestParam(defaultValue = "")String detail,
                                                          HttpServletRequest request){

        Map<String,Object> map = new HashMap<String, Object>();
        int pageNum = Integer.parseInt(request.getParameter("page"));
        int pageSize = Integer.parseInt(request.getParameter("limit"));
        map.put("uid",uid);
        map.put("pid",pid);
        map.put("state",state);
        map.put("order_status",order_status);
        map.put("user_name",user_name);
        map.put("user_phone",user_phone);
        map.put("provinces_cities",provinces_cities);
        map.put("city_county",city_county);
        map.put("tTown",tTown);
        map.put("detail",detail);
        PageInfo<Order> pageInfo2 =  orderService.selectOrderByNameLayui(map,pageNum,pageSize);

        //System.out.println("pageInfo2 = " + pageInfo2);
        //PageInfo<Order> pageInfo = orderService.selectUserOrders(map, pageNum, pageSize);
        return WebMapPageResult.success().setData(pageInfo2.getList()).setCount(pageInfo2.getTotal());
    }

    //查询申请退货退款订单信息
    @RequestMapping("/selectUserOrderByReason")
    @ResponseBody
    public WebMapPageResult selectUserOrderByReason(HttpServletRequest request){

        Map<String,Object> map = new HashMap<String, Object>();
        int pageNum = Integer.parseInt(request.getParameter("page"));
        int pageSize = Integer.parseInt(request.getParameter("limit"));

        PageInfo<Order> pageInfo = orderService.selectUserOrderByReason(map,pageNum,pageSize);

        return WebMapPageResult.success().setData(pageInfo.getList()).setCount(pageInfo.getTotal());
    }

    @RequestMapping("/findByIdOrder")
    @ResponseBody
    public Order findByIdOrder(Integer id){
        return orderService.selectByIdAndOrder(id);
    }

    @RequestMapping("/updateByIdOrder")
    @ResponseBody
    public boolean updateByIdOrder(Order order){
        int i = orderService.updateByIdOrderStatus(order);

        return i>0?true:false;
    }

    @RequestMapping("/updateByIdOrderByLayui")
    @ResponseBody
    public WebMapPageResult updateByIdOrderByLayui(@RequestParam(defaultValue = "id")Integer id, HttpServletRequest request){
        System.out.println("id = " + id);
        Order order = orderService.findOrderById(id);
        order.setOrder_status("已发货");
        orderService.updateByIdOrderStatus(order);
        return WebMapPageResult.success().setMessage("已发货");
    }

    //处理用户退货退款的订单
    @RequestMapping("/updateByIdOrderByUserAndProduct")
    @ResponseBody
    public WebMapPageResult updateByIdOrderByUserAndProduct(@RequestParam(defaultValue = "id")Integer id,HttpServletRequest request){

        Order order = orderService.findOrderById(id);

        //对商品进行修改
        Product product = order.getProduct();
        Integer count = product.getCount();
        count=count+order.getpCount();
        product.setCount(count);
        productService.updateById(product);

        //对商家账号进行修改   修改金额  根据商品中的商家名称查询对应商家
        String companies = product.getCompanies();
        Business business = businessService.selectByCompanies(companies);
        double balance = business.getBalance();
        balance = balance-order.getSumPCount();
        business.setBalance(balance);
        businessService.updateById(business);

        //对用户账户信息进行修改
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Double userMoney = user.getUser_money();
        userMoney = userMoney+order.getSumPCount();
        user.setUser_money(userMoney);
        userService.updateById(user);

        //对订单进行修改
        order.setState("已退款");
        order.setOrder_status("已退货");
        int i = orderService.updateOrderByIdAndStatedAndStatus(order);

        return WebMapPageResult.success().setMessage("退款，退货操作完成");
    }

    @RequestMapping("/updateOrderConfirmReceiving")
    @ResponseBody
    public boolean updateOrderConfirmReceiving(Integer id,String payment,HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        String userPayment = user.getPayment();
        if (payment.equals(userPayment)){
            Order order = new Order();
            order.setId(id);
            order.setOrder_evaluate("未评价");
            order.setOrder_status("已收货");
            orderService.updateOrderEvaluate(order);
            return true;
        }else {
            return false;
        }
    }

    /*根据订单评价或者未评价来查询*/
    @RequestMapping("/selectByOrderEvaluate")
    @ResponseBody
    public List<Order> selectByOrderEvaluate(String order_evaluate,HttpServletRequest request){

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("order_evaluate",order_evaluate);
        map.put("uid",user.getId());
        List<Order> orderList = orderService.selectByOrderEvaluate(map);
        return orderList;
    }

    /*
    * 在提交订单之前对订单进行修改
    * */
    @RequestMapping("/deleteOrderByIdAndUpdateMoneys")
    @ResponseBody
    public boolean deleteOrderByIdAndUpdateMoneys(Integer id,HttpServletRequest request){
        HttpSession session = request.getSession();
        Double subtotal = (Double) session.getAttribute("subtotal");
        Order order = orderService.selectByIdAndOrder(id);
        Product product = productService.findById(order.getPid());
        subtotal=subtotal-product.getPrice();
        session.setAttribute("subtotal",subtotal);

        System.out.println("order = " + order);
        int i = orderService.deleteById(order.getId());
        return i>0?true:false;
    }

    //申请退款  查询订单信息
    @RequestMapping("/selectOrderApplyForRefundById")
    @ResponseBody
    public Order selectOrderApplyForRefundById(Integer id){
        return orderService.selectOrderApplyForRefundById(id);
    }

    //申请退款
    @RequestMapping("/updateOrderApplySubmit")
    @ResponseBody
    public boolean updateOrderApplySubmit(Order order){
        //System.out.println("order = " + order);
        int i = orderService.updateOrderApplySubmit(order);
        return true;
    }

    //根据id查询订单信息
    @RequestMapping("/findOrderById")
    @ResponseBody
    public Map<String,Object> findOrderById(Integer id){

        Map<String,Object> map = new HashMap<String, Object>();
        List<OrderDetail> orderDetailList = orderDetailService.selectOrderDetail();
        Order order = orderService.findOrderById(id);
        map.put("orderDetailList",orderDetailList);
        map.put("order",order);
        return map;
    }

    @RequestMapping("/updateByIdAndOrder")
    @ResponseBody
    public boolean updateByIdAndOrder(HttpServletRequest request,Order order){

        HttpSession session = request.getSession();
        Double subtotal = (Double) session.getAttribute("subtotal");
        System.out.println("order = " + order);
        Integer orderId = order.getId();
        Order order2 = orderService.findOrderById(orderId);
        //将原来的总价格减去  原来购买的数量*单价
        Product product = order2.getProduct();
        Double price = product.getPrice();
        subtotal = subtotal-(price*order2.getpCount());

        subtotal=subtotal+(price*order.getpCount());
        session.setAttribute("subtotal",subtotal);

        order.setSumPCount(price*order.getpCount());
        order.setSubtotal(subtotal);
        int i = orderService.updateByIdAndOrder(order);
        return i>0?true:false;
    }

    /*根据订单编号删除订单*/
    @RequestMapping("/deleteOrderById")
    @ResponseBody
    public boolean deleteOrderById(Integer id){
        return orderService.deleteOrderById(id);
    }

    @RequestMapping("/delAddressById")
    @ResponseBody
    public boolean delAddressById(Integer id){
        return addressService.delById(id);
    }

}
