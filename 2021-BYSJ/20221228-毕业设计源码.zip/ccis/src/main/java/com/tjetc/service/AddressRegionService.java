package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.AddressRegion;

import java.util.List;
import java.util.Map;

public interface AddressRegionService {
    boolean add(AddressRegion addressRegion);

    PageInfo<AddressRegion> listByAndName(Map<String, Object> map, Integer pageNum, Integer pageSize);

    AddressRegion findById(Integer id);

    boolean updateById(AddressRegion addressRegion);

    boolean delById(Integer id);

    List<AddressRegion> selectByAddressRegion();
}
