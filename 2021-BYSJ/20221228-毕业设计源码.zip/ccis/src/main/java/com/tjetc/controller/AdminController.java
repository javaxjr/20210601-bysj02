package com.tjetc.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Admin;
import com.tjetc.domain.Order;
import com.tjetc.domain.User;
import com.tjetc.service.AdminService;
import com.tjetc.service.CommonService;
import com.tjetc.service.OrderService;
import com.tjetc.service.UserService;
import com.tjetc.util.WebMapPageResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @Autowired
    private UserService userService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private CommonService commonService;


    @GetMapping("/add_admin")
    public String add_admin() {
        return "admin/add_admin";
    }

    @PostMapping("/add_admin")
    @ResponseBody
    public boolean add_admin(Admin admin, MultipartFile photo, HttpServletRequest request) {
        if (photo != null) {
            String realPath = request.getServletContext().getRealPath("/admin_upload/");
            File file = new File(realPath);
            if (!file.exists()) {
                file.mkdir();
            }
            String filename = photo.getOriginalFilename();
            String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filename;
            File file1 = new File(file, uuidFileName);
            try {
                admin.setPermission("IDENTITY");
                photo.transferTo(file1);
                admin.setPhotopath("admin_upload/" + uuidFileName);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        Map<String, Object> map = new HashMap<String, Object>();
        map.put("admin", admin);
        //int i=adminService.add(admin);
        int i = commonService.addSave(map, Admin.getInstance());
        return i > 0 ? true : false;
    }

    @RequestMapping("/selectByMapProduct")
    @ResponseBody
    public List<Map<String,String>> selectByMapProduct(){

        JSONObject jsonObject=new JSONObject();
        jsonObject.put("name","张三");

        List<Map<String,String>> mapList= adminService.selectByMapProduct(jsonObject);

        List<Admin> adminList = JSONArray.parseArray(mapList.toString(), Admin.class);
        System.out.println("adminList = " + adminList);

        return mapList;
    }


    @RequestMapping("/listByName")
    public String listByName(@RequestParam(defaultValue = "") String name,
                             @RequestParam(defaultValue = "1") Integer pageName,
                             @RequestParam(defaultValue = "5") Integer pageSize, Model model, HttpServletRequest request) {
        //PageInfo<Admin> pageInfo = adminService.listByName(name, pageName, pageSize);

        HttpSession session = request.getSession();
        Admin admin = (Admin) session.getAttribute("admin");
        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("name", name);
        map.put("username", admin.getUsername());


        PageInfo<Admin> pageInfo = commonService.selectByName(map, pageName, pageSize, Admin.getInstance());

        System.out.println("pageInfo = " + pageInfo);


        List<Admin> list = pageInfo.getList();
        //System.out.println("pageInfo = " + pageInfo);
        model.addAttribute("page", pageInfo);
        model.addAttribute("list", list);
        model.addAttribute("name", name);
        return "admin/list_admin";
    }

    @RequestMapping("/findById")
    @ResponseBody
    public Admin findById(Integer id) {
        return adminService.findById(id);
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(Admin admin, MultipartFile photo, HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (photo != null && photo.getSize() > 0) {
            String realPath = request.getServletContext().getRealPath("/admin_upload/");
            File file = new File(realPath);
            if (file.exists()) {
                file.mkdir();
            }
            String filename = photo.getOriginalFilename();
            String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filename;
            File file1 = new File(file, uuidFileName);
            try {
                photo.transferTo(file1);
                admin.setPhotopath("admin_upload/" + uuidFileName);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        int i = adminService.updateById(admin);

        if ("LOCATION".equals(admin.getPermission())) {
            session.setAttribute("admin", admin);
        }
        return i > 0 ? true : false;
    }

    @RequestMapping("/updateAdminPasswordById")
    @ResponseBody
    public boolean updateAdminPasswordById(String passwordOne, String passwordTwo, HttpServletRequest request) {
        HttpSession session = request.getSession();
        Admin admin = (Admin) session.getAttribute("admin");
        if ((passwordOne.trim()).equals(admin.getPassword())) {
            admin.setPassword(passwordTwo.trim());
            int i = adminService.updateAdminPasswordById(admin);
            return i > 0 ? true : false;
        } else {
            return false;
        }

    }

    //管理员查看 用户退货订单信息
    @RequestMapping("/selectOrderByReasonsRefund")
    @ResponseBody
    public List<List<Order>> selectOrderByReasonsRefund() {

        List<List<Order>> listList = new ArrayList<List<Order>>();

        List<Order> orderList = orderService.selectOrderByReasonsRefund();
        List<Order> list = orderService.selectOrderByExpeditingDelivery();

        listList.add(orderList);
        listList.add(list);
        return listList;
    }

    //催发货的订单
    @RequestMapping("/selectUserOrderByExpeditingDelivery")
    @ResponseBody
    public WebMapPageResult selectUserOrderByExpeditingDelivery(HttpServletRequest request) {

        int pageNum = Integer.parseInt(request.getParameter("page"));
        int pageSize = Integer.parseInt(request.getParameter("limit"));
        List<Order> orderList = orderService.selectOrderByExpeditingDelivery();
        PageHelper.startPage(pageNum, pageSize);
        PageInfo<Order> pageInfo = new PageInfo<Order>(orderList);

        return WebMapPageResult.success().setData(pageInfo.getList()).setCount(pageInfo.getTotal());
    }

    //查询用户的信息
    @RequestMapping("/listByNameUser")
    public String listByNameUser(@RequestParam(defaultValue = "") String name,
                                 @RequestParam(defaultValue = "1") Integer pageNum,
                                 @RequestParam(defaultValue = "4") Integer pageSize, Model model) {
        PageInfo<User> pageInfo = userService.listByName(name, pageNum, pageSize);
        List<User> list = pageInfo.getList();

        model.addAttribute("page", pageInfo);
        model.addAttribute("name", name);
        System.out.println("model = " + model);
        return "user/list_user";
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean delById(Integer id) {
        return adminService.delById(id);
    }


    /*管理员登录*/
    /*@RequestMapping("/loginAdmin")
    @ResponseBody
    public boolean loginAdmin(String username,String password,HttpServletRequest request){

        HttpSession session = request.getSession();
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("username",username);
        map.put("password",password);
        Admin admin = adminService.selectByUsernameAndPassword(map);
        if (admin!=null){

            session.setAttribute("admin",admin);
            session.setAttribute("adminUsername",admin.getUsername());
            return true;
        }else {
            session.setAttribute("admin","");
            session.setAttribute("adminUsername","");
            return false;
        }
    }*/
}
