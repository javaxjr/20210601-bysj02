package com.tjetc.mapper;

import com.tjetc.domain.Product;
import com.tjetc.domain.Type;

import java.util.List;
import java.util.Map;

public interface TypeMapper {
    int add(Type type);

    List<Type> listByName(Map<String, Object> map);

    Type findById(Integer id);

    int updateById(Type type);

    int delById(Integer id);

    List<Type> selectByProductType();

    List<Type> selectProductByType(String type);
}
