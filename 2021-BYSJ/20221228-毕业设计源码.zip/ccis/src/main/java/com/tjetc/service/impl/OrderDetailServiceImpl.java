package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.OrderDetail;
import com.tjetc.mapper.OrderDetailMapper;
import com.tjetc.service.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class OrderDetailServiceImpl implements OrderDetailService {

    @Autowired
    private OrderDetailMapper orderDetailMapper;
    public int add(OrderDetail orderDetail) {
        return orderDetailMapper.add(orderDetail);
    }

    public PageInfo<OrderDetail> listByName(String name, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<OrderDetail> list=orderDetailMapper.listByName(name);
        PageInfo<OrderDetail> pageInfo = new PageInfo<OrderDetail>(list);
        return pageInfo;
    }

    public OrderDetail findById(Integer id) {
      return orderDetailMapper.findById(id);
    }

    public int updateById(OrderDetail orderDetail) {
        return orderDetailMapper.updateById(orderDetail);
    }

    public int deleById(Integer id) {
        return orderDetailMapper.deleById(id);
    }

    public PageInfo<OrderDetail> listByNameS(Map<String, Object> map, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<OrderDetail> list=orderDetailMapper.listByNameS(map);
        PageInfo<OrderDetail> pageInfo = new PageInfo<OrderDetail>(list);
        return pageInfo;
    }

    public List<OrderDetail> selectOrderDetail() {
        return orderDetailMapper.selectOrderDetail();
    }
}
