package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Address;
import com.tjetc.domain.AddressRegion;
import com.tjetc.domain.Admin;
import com.tjetc.service.AddressRegionService;
import com.tjetc.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/addressRegion")
public class AddressRegionController {
    @Autowired
    private AddressRegionService addressRegionService;
    @Autowired
    private CommonService commonService;

    @GetMapping("/add")
    public String add(){
        return "addressRegion/add_addressRegion";
    }
    @PostMapping("/add")
    public String add(AddressRegion addressRegion){
        //boolean add = addressRegionService.add(addressRegion);
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("addressRegion",addressRegion);
        commonService.addSave(map,new AddressRegion());
        return "redirect:/addressRegion/listByAndName";
    }

    @RequestMapping("/listByAndName")
    public String listByAndName(@RequestParam(defaultValue = "")String provinces_cities,
                                @RequestParam(defaultValue = "1")Integer pageNum,
                                @RequestParam(defaultValue = "10")Integer pageSize, Model model){
        Map<String,Object> map=new HashMap();

        map.put("provinces_cities",provinces_cities);
        //PageInfo<AddressRegion> pageInfo=addressRegionService.listByAndName(map,pageNum,pageSize);
        PageInfo<AddressRegion> pageInfo = commonService.selectByName(map, pageNum, pageSize, new AddressRegion());
        model.addAttribute("page",pageInfo);
        model.addAttribute("provinces_cities",provinces_cities);
        return "addressRegion/list_addressRegion";

    }

    @RequestMapping("/findById")
    @ResponseBody
    public AddressRegion findById(Integer id){
        return addressRegionService.findById(id);
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(AddressRegion addressRegion){
        return addressRegionService.updateById(addressRegion);
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean delById(Integer id){
        return addressRegionService.delById(id);
    }



}
