package com.tjetc.filter;


import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class CharacterFilter implements Filter {



    public void init(FilterConfig filterConfig) throws ServletException {
        System.out.println("这是过滤器的初始化方法 = ");
        //利用config对象获取初始化参数

    }



    /*
    * request：请求
        getRequestURI：获取请求的url
        indexOf（str）：求字符串内str出现的位置下标
        所以：request.getRequestURI().indexOf("1.jsp")的意思就是，求请求的url内“1.jsp”的位置，返回的是一个数字，代表出现的位置，-1表示不存在。通常和-1比较来表示是否包含指定的页面，常用于过滤器。
        例：if(request.getRequestURI().indexOf("1.jsp")){
        filterChain.doFilter(request,response);//给1.jsp放行

        }else{
        xxxxxx//不放行，进行别的操作

}
    *
    * */
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) servletRequest;
        HttpServletResponse res= (HttpServletResponse) servletResponse;

        //判断当前session是否有用户信息
        if (req.getSession().getAttribute("user") == null){
            //保存当前客户想要去的地址
            String goURL = req.getServletPath();//获得用户想要去的地址
            String param = req.getQueryString();//获得地址中携带的参数

            if (param!=null){
                //重新拼接好请求地址+参数
                goURL=goURL+"?"+param;
            }
            //把当前客户想要访问的地址 ，存储到session中
            req.getSession().setAttribute("goURL",goURL);

            //非法请求跳转到登录页面
            req.getSession().setAttribute("error","您还未登录、请先登录之后在访问");
            res.sendRedirect(req.getContextPath()+"/login_user.jsp");

        }else {
            //如果有下一个过滤则跳转、否则直接到目标页面
            filterChain.doFilter(servletRequest, servletResponse);
        }
    }


    public void destroy() {
        System.out.println("这是过滤器的销毁方法 = ");
    }
}
