package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Address;
import com.tjetc.domain.User;
import com.tjetc.service.AddressService;
import com.tjetc.service.CommonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/address")
public class AddressController {

    @Autowired
    private AddressService addressService;
    @Autowired
    private CommonService commonService;

    @GetMapping("/add")
    public String add(){
        return "address/add_address";
    }
    @PostMapping("/add")
    @ResponseBody
    public boolean add(Address address){
        //return addressService.addAddress(address);
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("address",address);
        return (commonService.addSave(map,new Address()))>0?true:false;
    }

    @RequestMapping("/listByAndName")
    public String listByAndName(@RequestParam(defaultValue = "")String user_name,
                                           @RequestParam(defaultValue = "")String user_phone,
                                           @RequestParam(defaultValue = "")String provinces_cities,
                                           @RequestParam(defaultValue = "")String city_county,
                                           @RequestParam(defaultValue = "")String tTown,
                                           @RequestParam(defaultValue = "")String detail,
                                           @RequestParam(defaultValue = "1")Integer pageNum,
                                           @RequestParam(defaultValue = "5")Integer pageSize, Model model){

        Map<String,Object> map=new HashMap<String, Object>();
        if (user_name!=null && user_name.trim().length()>0){
            user_name=user_name.trim();
        }
        map.put("userName",user_name);

        if (user_phone!=null && user_phone.trim().length()>0){
            user_phone=user_phone.trim();
        }
        map.put("userPhone",user_phone);


        if (provinces_cities!=null && provinces_cities.trim().length()>0){
            provinces_cities=provinces_cities.trim();
        }
        map.put("provinces_cities",provinces_cities);


        if (city_county!=null && city_county.trim().length()>0){
            city_county=city_county.trim();
        }
        map.put("city_county",city_county);

        if (tTown!=null && tTown.trim().length()>0){
            tTown=tTown.trim();
        }
        map.put("tTown",tTown);


        if (detail!=null && detail.trim().length()>0){
            detail=detail.trim();
        }
        map.put("detail",detail);
        PageInfo<Address> pageInfo=addressService.listByAndName(map,pageNum,pageSize);

        commonService.selectByName(map,pageNum,pageSize,new Address());

        model.addAttribute("page",pageInfo);
        return "/user/list_address";
    }

    @RequestMapping("/findById")
    @ResponseBody
    public Address findById(Integer id){
        return  addressService.findById(id);
    }

    @RequestMapping("/selectAddressDefaultByUid")
    @ResponseBody
    public Address selectAddressDefaultByUid(HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        int uid = user.getId();
        Address address = addressService.selectAddressDefaultByUid(uid);
        return address;
    }

    @RequestMapping("/updateById")
    @ResponseBody
   public boolean updateById(Address address){
        return addressService.updateById(address);
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean delById(Integer id){
        return addressService.delById(id);
    }


}
