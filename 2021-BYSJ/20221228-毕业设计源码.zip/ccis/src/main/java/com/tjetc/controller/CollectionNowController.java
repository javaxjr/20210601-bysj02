package com.tjetc.controller;

import com.tjetc.domain.CollectionNow;
import com.tjetc.domain.User;
import com.tjetc.service.CollectionNowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/collectionNow")
public class CollectionNowController {

    @Autowired
    private CollectionNowService collectionNowService;


    @RequestMapping("/addCollectionNow")
    @ResponseBody
    private boolean addCollectionNow(CollectionNow collectionNow){
        //System.out.println("collectionNow = " + collectionNow);
        int i = collectionNowService.addCollectionNow(collectionNow);

        return i>0?true:false;
    }

    /*查询收藏夹中是否已添加过了*/
    @RequestMapping("/selectByPidAndUid")
    @ResponseBody
    private boolean selectByPidAndUid(CollectionNow collectionNow){
        collectionNow = collectionNowService.selectByPidAndUid(collectionNow);
        //System.out.println("collectionNow = " + collectionNow);
        return collectionNow != null?true:false;
    }

    @RequestMapping("/selectByUserCollectionNow")
    @ResponseBody
    private List<CollectionNow>  selectByUserCollectionNow(HttpServletRequest request){
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        return collectionNowService.selectByUserCollectionNow(user.getId());

    }

    @RequestMapping("/deleteById")
    public String deleteById(Integer id){
        collectionNowService.deleteById(id);
        return "personal_user";
    }

}
