package com.tjetc.domain;

import java.util.Date;

/*评价商品信息的类*/
public class Evaluation {
    private Integer id;//唯一标识
    private Integer user_id;
    private Integer product_id;
    private Integer order_id;
    private String content;//评价的内容
    private String photopath;//用户收到货之后上传的图片，若没有，则默认是商品图片
    private Date eDate;//评论的时间

    private User user;
    private Product product;

    public Evaluation() {
    }

    public Evaluation(Integer id, Integer user_id, Integer product_id, Integer order_id, String content, String photopath, Date eDate, User user, Product product) {
        this.id = id;
        this.user_id = user_id;
        this.product_id = product_id;
        this.order_id = order_id;
        this.content = content;
        this.photopath = photopath;
        this.eDate = eDate;
        this.user = user;
        this.product = product;
    }

    @Override
    public String toString() {
        return "Evaluation{" +
                "id=" + id +
                ", user_id=" + user_id +
                ", product_id=" + product_id +
                ", order_id=" + order_id +
                ", content='" + content + '\'' +
                ", photopath='" + photopath + '\'' +
                ", eDate=" + eDate +
                ", user=" + user +
                ", product=" + product +
                '}';
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Date geteDate() {
        return eDate;
    }

    public void seteDate(Date eDate) {
        this.eDate = eDate;
    }

    public Integer getOrder_id() {
        return order_id;
    }

    public void setOrder_id(Integer order_id) {
        this.order_id = order_id;
    }

    public String getPhotopath() {
        return photopath;
    }

    public void setPhotopath(String photopath) {
        this.photopath = photopath;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public Integer getProduct_id() {
        return product_id;
    }

    public void setProduct_id(Integer product_id) {
        this.product_id = product_id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
