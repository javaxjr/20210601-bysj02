package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.AddressRegion;
import com.tjetc.mapper.AddressRegionMapper;
import com.tjetc.service.AddressRegionService;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AddressRegionServiceImpl implements AddressRegionService, ApplicationContextAware {

    @Autowired
    private AddressRegionMapper addressRegionMapper;
    public boolean add(AddressRegion addressRegion) {
        return (addressRegionMapper.add(addressRegion))>0?true:false;
    }

    public PageInfo<AddressRegion> listByAndName(Map<String, Object> map, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<AddressRegion> list=addressRegionMapper.listByAndName(map);
        PageInfo<AddressRegion> pageInfo = new PageInfo<AddressRegion>(list);

        return pageInfo;
    }

    public AddressRegion findById(Integer id) {
        return addressRegionMapper.findById(id);
    }

    public boolean updateById(AddressRegion addressRegion) {
        return (addressRegionMapper.updateById(addressRegion))>0?true:false;
    }

    public boolean delById(Integer id) {
        return (addressRegionMapper.delById(id))>0?true:false;
    }

    public List<AddressRegion> selectByAddressRegion() {
        return addressRegionMapper.selectByAddressRegion();
    }

    @Override
    public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {

    }
}
