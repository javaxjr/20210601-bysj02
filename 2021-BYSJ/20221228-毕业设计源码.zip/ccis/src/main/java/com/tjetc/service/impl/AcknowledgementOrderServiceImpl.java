package com.tjetc.service.impl;

import com.tjetc.domain.AcknowledgementOrder;
import com.tjetc.mapper.AcknowledgementOrderMapper;
import com.tjetc.service.AcknowledgementOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AcknowledgementOrderServiceImpl implements AcknowledgementOrderService {

    @Autowired
    private AcknowledgementOrderMapper acknowledgementOrderMapper;
    public int addSubmit(AcknowledgementOrder acknowledgementOrder) {
        return acknowledgementOrderMapper.addSubmit(acknowledgementOrder);
    }

    public int updateOrderStatus(String order_status) {
        return acknowledgementOrderMapper.updateOrderStatus(order_status);
    }

    public List<AcknowledgementOrder> selectByOrderStatus(String order_status) {
        return acknowledgementOrderMapper.selectByOrderStatus(order_status);
    }

    public int deleteById(Integer id) {
        return acknowledgementOrderMapper.deleteById(id);
    }
}
