package com.tjetc.domain;

/**
 * 收货地址表
 *
 */
public class Address extends AddressRegion{
    //private Integer id;//地址id
    private Integer user_id;//用户id
    /*订单中商品的地址*/
    private String user_name;//收货人名称
    //private String provinces_cities;//省市
    private String city_county;//市县
    private String tTown;//城镇，或者是所在的区
    private String detail;//详细地址
    private String user_phone;//用户联系方式
    private String default_address;//默认收货地址标志 0：不是  1：是默认的收货地址

    public Address() {
    }

    @Override
    public String toString() {
        return "Address{" +
                "user_id=" + user_id +
                ", user_name='" + user_name + '\'' +
                ", city_county='" + city_county + '\'' +
                ", tTown='" + tTown + '\'' +
                ", detail='" + detail + '\'' +
                ", user_phone='" + user_phone + '\'' +
                ", default_address='" + default_address + '\'' +
                '}';
    }


    public String getDefault_address() {
        return default_address;
    }

    public void setDefault_address(String default_address) {
        this.default_address = default_address;
    }

    public Integer getUser_id() {
        return user_id;
    }

    public void setUser_id(Integer user_id) {
        this.user_id = user_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getUser_phone() {
        return user_phone;
    }

    public void setUser_phone(String user_phone) {
        this.user_phone = user_phone;
    }

    public String getCity_county() {
        return city_county;
    }

    public void setCity_county(String city_county) {
        this.city_county = city_county;
    }

    public String gettTown() {
        return tTown;
    }

    public void settTown(String tTown) {
        this.tTown = tTown;
    }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }
}
