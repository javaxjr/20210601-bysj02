package com.tjetc.controller;

import com.tjetc.util.RandomValidateCodeUtil;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.image.BufferedImage;

/*
* 获取图像验证码 控制层
* */
@Controller
@RequestMapping("/verifyCode")
public class VerifyCodeController {

    private static final long serialVersionUID = 1L;


    //获取图像验证码
    @RequestMapping("/getRandomValidateCode")
    @ResponseBody
    public String getRandomValidateCode(HttpServletRequest request, HttpServletResponse response, Model model){

        response.setContentType("image/jpg");//设置相应类型,告诉浏览器输出的内容为图片
        response.setHeader("Pragma", "No-cache");//设置响应头信息，告诉浏览器不要缓存此内容

        //实现浏览器兼容
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expire", 0);

        RandomValidateCodeUtil rcu = new RandomValidateCodeUtil();

        String randcode = rcu.getRandcode(request, response);//调用输出图片方法

        System.out.println("randcode = " + randcode);

        return randcode;
    }

}
