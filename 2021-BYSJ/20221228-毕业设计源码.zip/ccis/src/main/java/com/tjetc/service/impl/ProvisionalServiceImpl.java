package com.tjetc.service.impl;

import com.tjetc.domain.Product;
import com.tjetc.domain.Provisional;
import com.tjetc.mapper.ProductMapper;
import com.tjetc.mapper.ProvisionalMapper;
import com.tjetc.service.ProvisionalService;
import com.tjetc.util.excel.UploadExcelAndList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@Service
public class ProvisionalServiceImpl implements ProvisionalService {

    @Autowired
    private ProvisionalMapper provisionalMapper;

    public int add(Provisional provisional) {
        return provisionalMapper.add(provisional);
    }

    public int delByPIdAndUId(Provisional provisional) {
        return provisionalMapper.delByPIdAndUId(provisional);
    }

    public List<Provisional> selectByProvisional(Integer user_id) {
        return provisionalMapper.selectByProvisional(user_id);
    }

    public void deletes() {
        provisionalMapper.deletes();
    }

    public List<Provisional> selectByProvisional2() {
        return provisionalMapper.selectByProvisional2();
    }

    public List<Provisional> selectByUserId(Integer id) {
        return provisionalMapper.selectByUserId(id);
    }

    public int deleteByMyCartId(Integer myCart_id) {
        return provisionalMapper.deleteByMyCartId(myCart_id);
    }

    public int delByUid(Integer uid) {
        return provisionalMapper.delByUid(uid);
    }


}
