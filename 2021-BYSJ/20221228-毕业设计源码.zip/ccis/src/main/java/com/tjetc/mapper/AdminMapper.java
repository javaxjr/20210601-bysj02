package com.tjetc.mapper;

import com.alibaba.fastjson.JSONObject;
import com.tjetc.domain.Admin;

import java.util.List;
import java.util.Map;

public interface AdminMapper {
    int add(Admin admin);

    Admin findById(Integer id);

    List<Admin> listByName(Map<String, Object> map);

    int updateById(Admin admin);

    int delById(Integer id);

    Admin selectByUsernameAndPassword(Map<String, Object> map);

    int updateAdminPasswordById(Admin admin);

    Admin selectUserNameByPhone(Map<String,Object> map);

    JSONObject selectByMapProduct(JSONObject jsonObject);
}
