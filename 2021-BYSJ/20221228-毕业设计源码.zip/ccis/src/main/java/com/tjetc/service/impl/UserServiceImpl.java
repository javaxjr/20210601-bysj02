package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.User;
import com.tjetc.mapper.UserMapper;
import com.tjetc.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserMapper userMapper;

    public int addUser(User user) {
        return userMapper.addUser(user);
    }

    public PageInfo<User> listByName(String name, Integer pageNum, Integer pageSize) {
        PageHelper.startPage(pageNum,pageSize);
        List<User> list= userMapper.listByName(name);
        PageInfo<User> pageInfo = new PageInfo<User>(list);
        return pageInfo;
    }

    public User findById(Integer id) {
        return userMapper.findById(id);
    }

    public boolean delById(Integer id) {
        return userMapper.delById(id);
    }

    public User selectUsernameAndPassword(String username, String password) {
        Map map =new HashMap<String,Object>();
        map.put("username",username);
        map.put("password",password);
        User user = userMapper.selectUsernameAndPassword(map);
        return user;
    }

    public int updateByUserMoney(User user) {
        return userMapper.updateByUserMoney(user);
    }

    public int updateByUserPaymentPassword(User user) {
        return userMapper.updateByUserPaymentPassword(user);
    }

    public int updateById(User user) {
        return userMapper.updateById(user);
    }

    public int updateUserAndPassword(User user) {
        return userMapper.updateUserAndPassword(user);
    }

    public int updateUserGrade(User user) {
        return userMapper.updateUserGrade(user);
    }

    public int updateUserRechargeAndMoney(User user) {
        return userMapper.updateUserRechargeAndMoney(user);
    }

    public User selectByUserObject(Map<String,Object> map) {
        return userMapper.selectByUserObject(map);
    }

    public User findByUsername(String username) {
        return userMapper.findByUsername(username);
    }

    public int updateSetUpUserPayment(User user) {
        return userMapper.updateByUserPaymentPassword(user);
    }
}
