package com.tjetc.service;

import com.tjetc.domain.AcknowledgementOrder;

import java.util.List;

public interface AcknowledgementOrderService {
    int addSubmit(AcknowledgementOrder acknowledgementOrder);

    int updateOrderStatus(String order_status);

    List<AcknowledgementOrder> selectByOrderStatus(String order_status);

    int deleteById(Integer id);
}
