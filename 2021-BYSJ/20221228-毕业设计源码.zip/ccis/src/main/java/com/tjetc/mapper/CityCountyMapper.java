package com.tjetc.mapper;

import com.tjetc.domain.CityCounty;

import java.util.List;
import java.util.Map;

public interface CityCountyMapper {
    int add(CityCounty cityCounty);

    List<CityCounty> selectByName(Map<String, Object> map);

    CityCounty selectById(Integer id);

    int updateById(CityCounty cityCounty);

    int delById(Integer id);

    List<CityCounty> selectByCtyCounty(String provinces_cities);
}
