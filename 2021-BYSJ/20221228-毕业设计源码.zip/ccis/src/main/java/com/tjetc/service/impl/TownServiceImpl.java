package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Town;
import com.tjetc.mapper.TownMapper;
import com.tjetc.service.TownService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;


@Service
public class TownServiceImpl implements TownService {

    @Autowired
    private TownMapper townMapper;
    public int add(Town town) {
        return townMapper.add(town);
    }

    public PageInfo<Town> selectByName(Map<String, Object> map, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<Town> list=townMapper.selectByName(map);
        PageInfo<Town> pageInfo = new PageInfo<Town>(list);

        return pageInfo;
    }

    public Town selectById(Integer id) {
        return townMapper.selectById(id);
    }

    public int updateById(Town town) {
        return townMapper.updateById(town);
    }

    public int delById(Integer id) {
        return townMapper.delById(id);
    }

    public List<Town> selectByTTownAndCityCounty(String city_county) {
        return townMapper.selectByTTownAndCityCounty(city_county);
    }
}
