package com.tjetc.service;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Address;

import java.util.List;
import java.util.Map;

public interface AddressService {
    boolean addAddress(Address address);

    PageInfo<Address> listByAndName(Map<String, Object> map, Integer pageNum, Integer pageSize);

    Address findById(Integer id);

    boolean updateById(Address address);

    boolean delById(Integer id);

    List<Address> selectAddress(Integer user_id);

    void updateByDefaultAddress(Map<String,Object> map);

    Address selectAddressDefaultByUid(int uid);
}
