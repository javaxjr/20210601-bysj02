package com.tjetc.test;


import java.util.List;

/*
WebService客户端测试类  远程调用服务中的方法
* */
public class WebServiceTest {
    public static void main(String[] args) {
       /* //创建视图
        WeatherQueryImplService weatherQueryImplService =new WeatherQueryImplService();
        //根据服务视图得到的服务方法
       WeatherQueryImpl weatherQuery =  weatherQueryImplService.getPort(WeatherQueryImpl.class);
       //调用weathQueryImpl服务中的方法
        List<String> list = weatherQuery.query2Days();

        String s = weatherQuery.queryNowTem();

        System.out.println( s);

        System.out.println(list);*/

    }

}
