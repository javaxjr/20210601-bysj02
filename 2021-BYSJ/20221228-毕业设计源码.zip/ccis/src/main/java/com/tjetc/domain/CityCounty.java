package com.tjetc.domain;

/*
* 市县表
* */
public class CityCounty extends AddressRegion{

    private String city_county;//区县
    public CityCounty() {
    }

    @Override
    public String toString() {
        return "CityCounty{" +
                "city_county='" + city_county + '\'' +
                '}';
    }

    public String getCity_county() {
        return city_county;
    }

    public void setCity_county(String city_county) {
        this.city_county = city_county;
    }
}
