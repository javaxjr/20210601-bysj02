package com.tjetc.controller;

import com.github.pagehelper.PageInfo;
import com.tjetc.domain.OrderDetail;
import com.tjetc.service.OrderDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/orderDetail")
public class OrderDetailController {

    @Autowired
    private OrderDetailService orderDetailService;

    @GetMapping("/add")
    public String add(){
        return "orderDetail/add_orderDetail";
    }

    @PostMapping("/add")
    @ResponseBody
    public boolean add(OrderDetail orderDetail){
        int i= orderDetailService.add(orderDetail);
        return i>0?true:false;

    }

    @RequestMapping("/listByName")
    public String listByName(@RequestParam(defaultValue = "") String name,
                             @RequestParam(defaultValue = "") String  brand,
                             @RequestParam(defaultValue = "") String  size,
                             @RequestParam(defaultValue = "") String  patten,
                             @RequestParam(defaultValue = "") String  year,
                             @RequestParam(defaultValue = "") String  target,
                             @RequestParam(defaultValue = "1") Integer pageNum,
                             @RequestParam(defaultValue = "8") Integer pageSize,
                             Model model){

        Map<String, Object> map = new HashMap<String, Object>();
       // map.put("name",name);
        map.put("brand",brand);
        map.put("size",size);
        map.put("patten",patten);
        map.put("year",year);
        map.put("target",target);

        PageInfo<OrderDetail> detailPageInfo=orderDetailService.listByNameS(map,pageNum,pageSize);


        //PageInfo<OrderDetail> pageInfo=orderDetailService.listByName(name,pageNum,pageSize);

        model.addAttribute("page",detailPageInfo);
        //model.addAttribute("name",name);
        model.addAttribute("brand",brand);
        model.addAttribute("size",size);
        model.addAttribute("patten",patten);
        model.addAttribute("year",year);
        model.addAttribute("target",target);
        return "orderDetail/list_orderDetail";
    }

    @RequestMapping("/findById")
    public String findById(Integer id,Model model){
        //System.out.println("id = " + id);
        OrderDetail orderDetail = orderDetailService.findById(id);
        model.addAttribute("od",orderDetail);
        return "orderDetail/update_orderDetail";
    }

    @RequestMapping("/updateById")
    @ResponseBody
    public boolean updateById(OrderDetail orderDetail){
        int i=orderDetailService.updateById(orderDetail);
        return i>0?true:false;
    }

    @RequestMapping("/delById")
    @ResponseBody
    public boolean deleById(Integer id){
        int i=orderDetailService.deleById(id);
        return i>0?true:false;
    }

}
