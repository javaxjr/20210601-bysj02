package com.tjetc.domain;

//import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/*
* 用户表
* */
@Data
public class User extends People{

    private String payment;//支付密码

    private Double user_money;//用户金额
    private String grade;//用户会员等级  根据用户的金额而定
    private String address;//所在省市
    private String address_cityPicker;//所在市县
    private String address_detail;//详细地址
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    /*@JsonFormat(pattern = "yyyy-MM-dd",timezone = "GMT+8")*/
    private Date register_date;//注册时间

    private static final User user = new User();

    private User() {
    }

    public static User getInstance(){
        return user;
    }

}
