package com.tjetc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tjetc.domain.Business;
import com.tjetc.mapper.BusinessMapper;
import com.tjetc.service.BusinessService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusinessServiceImpl implements BusinessService {

    @Autowired
    private BusinessMapper businessMapper;

    public int add(Business business) {
        return businessMapper.add(business);
    }

    public Business selectByCompanies(String companies) {
        return businessMapper.selectByCompanies(companies);
    }

    public int updateByBalance(Business business) {
        return businessMapper.updateByBalance(business);
    }

    public boolean deleteById(Integer id) {
        return businessMapper.deleteById(id);
    }

    public int updateById(Business business) {
        return businessMapper.updateById(business);
    }

    public Business findById(Integer id) {
        return businessMapper.findById(id);
    }

    public PageInfo<Business> selectByBusinessName(String business_name, Integer pageNum, Integer pageSize) {

        PageHelper.startPage(pageNum,pageSize);
        List<Business> businessList = businessMapper.selectByBusinessName(business_name);
        PageInfo<Business> pageInfo = new PageInfo<Business>(businessList);
        return pageInfo;
    }
}
