package com.tjetc.controller;

import com.tjetc.domain.Admin;
import com.tjetc.domain.Order;
import com.tjetc.domain.User;
import com.tjetc.domain.UserLoginAndTimeline;
import com.tjetc.service.*;
import com.tjetc.util.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.File;
import java.io.IOException;
import java.util.*;

@Controller
@RequestMapping("/LoginAndRegister")
public class LoginAndRegisterController {

    @Autowired
    private UserService userService;
    @Autowired
    private ProvisionalService provisionalService;
    @Autowired
    private AdminService adminService;
    @Autowired
    private OrderService orderService;
    @Autowired
    private UserLoginAndTimelineService userLoginAndTimelineService;
    //用户注册  以下为一系列的验证
    @RequestMapping("/selectByUserObject")
    @ResponseBody
    private boolean selectByUserName(@RequestParam(defaultValue = "") String username,
                                     @RequestParam(defaultValue = "") String phone, Model model){

        Map<String,Object> map = new HashMap<String, Object>();
        map.put("username",username);
        map.put("phone",phone);

        model.addAttribute("username",username);
        model.addAttribute("phone",phone);
        User user = userService.selectByUserObject(map);
        return user!=null?true:false;
    }

    //后台自动生成验证码
    @RequestMapping("/selectAutomaticGeneration")
    @ResponseBody
    public Map<String,Object> selectAutomaticGeneration(Model model){
        String uuidCode = UUID.randomUUID().toString().replaceAll("-","");
        Map<String,Object> map = new HashMap<String,Object>();
        String s = uuidCode.substring(0, 6);
        System.out.println("uuidCode = " + uuidCode);
        map.put("s",s);
        return map;
    }



    //验证都通过之后，添加用户信息到数据库表中 注册成功
    @RequestMapping("/add_user")
    @ResponseBody
    public boolean addUser(User user, MultipartFile photo, HttpServletRequest request, Model model){
        if (photo!=null && photo.getSize()>0){
            String realPath = request.getServletContext().getRealPath("/user_upload/");
            File file = new File(realPath);
            if (!file.exists()){
                file.mkdir();
            }
            String filename = photo.getOriginalFilename();
            System.out.println("filename = " + filename);
            String filenameUUID = UUID.randomUUID().toString().replace("-","")+filename.substring(filename.lastIndexOf("."));
            System.out.println("filenameUUID = " + filenameUUID);
            File file2 = new File(file, filenameUUID);
           /* String uuid = UUID.randomUUID().toString().replaceAll("-", "").substring(0, 8);
            String uuidFileName = uuid + filenameUUID;*/
            try {
                photo.transferTo(file2);
            } catch (IOException e) {
                e.printStackTrace();
            }
            user.setPhotopath("user_upload/"+filenameUUID);
        }else{
            user.setPhotopath("user_upload/599e55c4d4cd49f5879e69988533c98c.jpg");
        }
        //给登录密码进行加密
        String password = user.getPassword();
        String passwordMd5 = MD5Utils.stringToMD5(password);
        user.setPassword(passwordMd5);
        //给支付密码加密
        String payment = user.getPayment();
        if (payment!=null && payment.length()>0){
            String paymentMd5 = MD5Utils.stringToMD5(payment);
            user.setPayment(paymentMd5);
        }
        //设置用户初始余额
        user.setUser_money(0.0);
        //用户会员等级  根据余额来评定等级  钻石 打9折，星耀 打8折，王者  打7折
        Double user_money = user.getUser_money();
        if (user_money>=0.0 && user_money<100){
            user.setGrade("钻石");
        }else if (user_money>=100 && user_money<500){
            user.setGrade("星耀");
        }else if (user_money>=500){
            user.setGrade("王者");
        }
        user.setRegister_date(new Date());
        System.out.println("user = " + user);
        int i=userService.addUser(user);

        return i>0?true:false;
    }


    //用户登录
    @RequestMapping(value = "/loginUser",method = RequestMethod.POST)
    @ResponseBody
    public boolean usernameAndPassword(@RequestParam(defaultValue = "") String username,
                                       @RequestParam(defaultValue = "") String password,
                                       @RequestParam String readLogin, HttpServletRequest request, HttpServletResponse response){



        password= MD5Utils.stringToMD5(password);
        password="96e79218965eb72c92a549dd5a330112";
        HttpSession session = request.getSession();
        User user=userService.selectUsernameAndPassword(username,password);
        System.out.println("user = " + user);
        if (user!=null){
            //登录成功后，清空上一次用户登录时的临时表
            provisionalService.deletes();
            /*每次用户登录之后判断  用户账户金额 从而修改用户的等级  从而打相应的折扣*/
            Double user_money = user.getUser_money();
            if (user_money>=0.0 && user_money<100){
                user.setGrade("钻石");
            }else if (user_money>=100 && user_money<500){
                user.setGrade("星耀");
            }else if (user_money>=500){
                user.setGrade("王者");
            }
            int i = userService.updateUserGrade(user);
            session.setAttribute("user",user);
            session.setAttribute("username",username);

            //判断用户是否勾选七天免登录
            if ("true".equals(readLogin)){
                Cookie cookie = new Cookie("username",username);
                cookie.setPath("/");
                cookie.setMaxAge(60*60*24*7);
                response.addCookie(cookie);
            }
            UserLoginAndTimeline usertimeline = new UserLoginAndTimeline();
            usertimeline.setUid(user.getId());
            usertimeline.setUserLoginDate(new Date());
            userLoginAndTimelineService.addUserTimeline(usertimeline);
            //session.setAttribute("password",password);
            return true;
        }else {
            session.setAttribute("user",null);
            session.setAttribute("username","");
            //session.setAttribute("password","");
            return false;
        }
    }

    /*管理员登录*/
    @RequestMapping("/loginAdmin")
    @ResponseBody
    public boolean loginAdmin(String username,String password,HttpServletRequest request){

        HttpSession session = request.getSession();
        Map<String,Object> map = new HashMap<String, Object>();
        map.put("username",username);
        map.put("password",password);
        Admin admin = adminService.selectByUsernameAndPassword(map);
        if (admin!=null){

            session.setAttribute("admin",admin);
            session.setAttribute("adminUsername",admin.getUsername());
            return true;
        }else {
            session.setAttribute("admin",null);
            session.setAttribute("adminUsername","");
            return false;
        }
    }

    //找回密码  重置密码
    @RequestMapping("/codeYou")
    @ResponseBody
    public boolean codeYou(Admin admin){

        String phone = admin.getPhone();
        String username = admin.getUsername();
        Map<String,Object> map =new HashMap<String, Object>();
        map.put("phone",phone);
        map.put("username",username);
        admin = adminService.selectUserNameByPhone(map);
        System.out.println("admin = " + admin.getPassword());
        if (admin!=null){
            admin.setPassword("123456");
            adminService.updateAdminPasswordById(admin);
            return true;
        }else {
            return false;
        }
    }

    //管理员后台管理  用户退出账号  退出账号
    @RequestMapping("/signOut")
    public String signOutAdmin(String op,HttpServletRequest request){
        HttpSession session = request.getSession();
        //管理员退出
        if ("signOutAdmin".equals(op)){
            session.setAttribute("admin",null);
            session.setAttribute("adminUsername","");
            return "/admin/loginAdmin";
       //用户退出账号
        }else{
            session.setAttribute("user",null);
            session.setAttribute("username","");
            return "index";
        }
    }

}
